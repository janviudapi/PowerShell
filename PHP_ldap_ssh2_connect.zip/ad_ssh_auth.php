<?php
    // Start the session
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AD Authentication and SSH</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- Bootstrap Icons CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">

        <style>
            .centerimg {
                display: block;
                margin-left: auto;
                margin-right: auto;
                width: 10%;
              }
        </style>
    </head>
    <body>
        <div class="container custom-container">
            <div class="card">
                <div class="card-body">
                    <img class="centerimg" src="loremlogo.jpg" alt="loremlogo"> <!-- Image above the text -->
                    <?php
                        // LDAP server settings
                        $ldapServer = '192.168.34.11'; //'ldap.vcloud-lab.com';
                        $ldapPort = 389; // Default LDAP port

                        //Encrypt SSH Password
                        //[guid]::NewGuid()
                        //C:\xampp\php> php -r "$key = 'dce45e93-c278-4727-bad2-95df27cfbbf0'; $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc')); echo base64_encode(openssl_encrypt('Computer@123', 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv)) . ':::' . base64_encode($iv);"

                        // Decrypt SSH Password
                        // Encrypted data and IV received from the client from above command
                        $encryptedDataWithIV = 'LPUKPDQEs3wUewq6OCweZA==:::lXZQ8KFkLa8nTkdLbDrjJw==';

                        // Separate the encrypted data and IV
                        list($encryptedData, $iv) = explode(':::', $encryptedDataWithIV);

                        // Load the encryption key securely from a file or environment variable
                        $key = file_get_contents('extras/key'); // Example: 'dce45e93-c278-4727-bad2-95df27cfbbf0' //path/to/secure/key

                        // Decode the IV and the encrypted data from base64
                        $decodedIV = base64_decode($iv);
                        $decodedEncryptedData = base64_decode($encryptedData);

                        // Decrypt the data using openssl_decrypt
                        $decryptedData = openssl_decrypt($decodedEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $decodedIV);

                        //echo $decryptedData;

                        // SSH server settings
                        $sshUsername = 'ubuntu'; //'ssh_username'; // SSH username (replace with actual username)
                        $sshPassword = $decryptedData; //'ssh_password'; // SSH password (replace with actual password)

                        // Get LDAP username, password, and SSH IP from form submission
                        $ldapUsername = isset($_POST['ldapUsername']) ? $_POST['ldapUsername'] : '';
                        $ldapPassword = isset($_POST['ldapPassword']) ? $_POST['ldapPassword'] : '';
                        $sshHost = isset($_POST['sshHost']) ? $_POST['sshHost'] : '';

                        if ($ldapPassword !== '')
                        {
                            // Attempt to connect to LDAP server
                            $ldapConnection = @ldap_connect($ldapServer, $ldapPort);
                        }

                        // Check if connection was successful
                        if ($ldapConnection) {
                            // Attempt to bind to LDAP server with provided credentials
                            $ldapBind = @ldap_bind($ldapConnection, $ldapUsername, $ldapPassword);

                            // Check if bind was successful
                            if ($ldapBind) {
                                //echo "LDAP bind successful<br>";
                                echo '<h5 class="mt-4 d-flex justify-content-center align-items-center"> <i class="bi bi-check2-circle" style="color:lime;"></i> &nbsp;Credential verification successful</h5>';

                                // Attempt to connect to SSH server
                                $connection = @ssh2_connect($sshHost, 22);

                                // Check if SSH connection was successful
                                if ($connection) {
                                    // Authenticate with SSH server
                                    if (@ssh2_auth_password($connection, $sshUsername, $sshPassword)) {
                                        //echo "SSH authentication successful<br>";
                                        echo '<h5 class="mt-4 d-flex justify-content-center align-items-center"> <i class="bi bi-check2-circle" style="color:lime;"></i> &nbsp;SSH authentication successful</h5>';

                                        // SSH command to execute
                                        //$command = 'ls -la';
                                        $command = 'sudo uptime';

                                        // Execute SSH command
                                        $stream = ssh2_exec($connection, $command);

                                        if ($stream) {
                                            // Read command output
                                            stream_set_blocking($stream, true);
                                            $output = stream_get_contents($stream);
                                            fclose($stream);

                                            // Output command output
                                            //echo "Command output:<br>$output";
                                            echo "<h6 class='mt-4 d-flex justify-content-center align-items-center'/><br><br>Command output:</h6>";
                                            echo "<h6 class='mt-4 d-flex justify-content-center align-items-center'/>$output</h6>";

                                        } else {
                                            //echo "Failed to execute command";
                                            echo '<h6 class="mt-4 d-flex justify-content-center align-items-center"> <i class="bi bi-exclamation-triangle" style="color:crimson;"></i> &nbsp;Failed to execute command</h6>';
                                        }
                                    } else {
                                        //echo "SSH authentication failed";
                                        echo '<h5 class="mt-4 d-flex justify-content-center align-items-center"> <i class="bi bi-exclamation-triangle" style="color:crimson;"></i> &nbsp;SSH authentication failed</h5>';
                                    }

                                    // Close SSH connection
                                    ssh2_disconnect($connection);
                                } else {
                                    //echo "Failed to connect to SSH server";
                                    echo '<h5 class="mt-4 d-flex justify-content-center align-items-center"> <i class="bi bi-exclamation-triangle" style="color:crimson;"></i> &nbsp;Failed to connect to SSH server</h5>';
                                }
                            } else {
                                //echo "LDAP bind failed: " . ldap_error($ldapConnection);
                                // echo "<h5 class='mt-4 d-flex justify-content-center align-items-center'><i class='bi bi-exclamation-triangle' style='color:crimson;'></i> &nbsp;Domain connection failed: . ldap_error($ldapConnection)</h5>";
                                echo '<h5 class="mt-4 d-flex justify-content-center align-items-center"> <i class="bi bi-exclamation-triangle" style="color:crimson;"></i> &nbsp;Username or Password incorrect</h5>';
                            }

                            // Close LDAP connection
                            ldap_close($ldapConnection);
                        } else {
                            //echo "Unable to connect to LDAP server: " . ldap_error($ldapConnection);
                            echo '<h5 class="mt-4 d-flex justify-content-center align-items-center"> <i class="bi bi-exclamation-triangle" style="color:crimson;"></i> &nbsp;Username or Password incorrect</h5>';
                        }
                        echo '<button onclick="window.location.href=\'index.html\'" class="btn btn-primary mt-4 d-flex justify-content-center align-items-center">Go Back to Site</button>';
                    ?>
                </div>
            </div>
        </div>
        <?php
            // remove all session variables
            session_unset();

            // destroy the session
            session_destroy();
        ?>
    </body>
</html>




