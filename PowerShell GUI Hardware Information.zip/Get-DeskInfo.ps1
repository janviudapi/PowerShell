#Load required libraries
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing 

#Website: http://vcloud-lab.com
#Written By: vJanvi
#Date: 20 May 2021
#Tested Environment:
    #Microsoft Windows 11
    #PowerShell Version 5.1, 7

#Read xaml file
$xamlFile = "$PSScriptRoot\DeskInfo.xaml"
$xamlContent = Get-Content -Path $xamlFile -ErrorAction Stop

#[xml]$xaml = $xamlContent -replace 'mc:Ignorable="d"', '' -replace "x:N", 'N' -replace 'x:Class=".*?"', '' -replace 'd:DesignHeight="\d*?"', '' -replace 'd:DesignWidth="\d*?"', ''
[xml]$xaml = $xamlContent -replace 'x:Class=".*?"', '' -replace 'xmlns:d="http://schemas.microsoft.com/expression/blend/2008"', '' -replace 'mc:Ignorable="d"', ''

#Read the forms in xaml
$reader = (New-Object System.Xml.XmlNodeReader $xaml) 
$form = [Windows.Markup.XamlReader]::Load($reader) 

#AutoFind all controls
$xaml.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]")  | ForEach-Object { 
    New-Variable  -Name $_.Name -Value $form.FindName($_.Name) -Force 
}

$iconImage.Source = "$PSScriptRoot\info.png"
#$hardwareInfo.Content = "Hardware Info V1"

$textboxUserName.Add_GotFocus({
    if ($textboxUserName.Text -eq 'Type Remote System UserName') {
        $textboxUserName.Foreground = 'Black'
        $textboxUserName.Text = ''
    }
})
$textboxUserName.Add_LostFocus({
    if ($textboxUserName.Text -eq '') {
        $textboxUserName.Text = 'Type Remote System UserName'
        $textboxUserName.Foreground = 'Darkgray'
    }
})

$passwordboxPassword.Add_GotFocus({
    if ($passwordboxPassword.Text -eq 'Type Remote System Password') {
        $passwordboxPassword.Foreground = 'Black'
        $passwordboxPassword.Text = ''
    }
})
$passwordboxPassword.Add_LostFocus({
    if ($passwordboxPassword.Text -eq '') {
        $passwordboxPassword.Text = 'Type Remote System Password'
        $passwordboxPassword.Foreground = 'Darkgray'
    }
})

$checkBoxNoCreds.Add_Checked({
    $textboxUserName.Visibility = 'Hidden'
    $passwordboxPassword.Visibility = 'Hidden'
})
$checkBoxNoCreds.Add_Unchecked({
    $textboxUserName.Visibility = 'Visible'
    $passwordboxPassword.Visibility = 'Visible'
})

$serverNameTextBox.Text = $env:COMPUTERNAME

$getHwInfobutton.Add_Click({

    function Show-MessageBox {   
        param (   
          [string]$Message = "Show user friendly Text Message",   
          [string]$Title = 'Title here',   
          [ValidateRange(0,5)]   
          [Int]$Button = 0,   
          [ValidateSet('None','Hand','Error','Stop','Question','Exclamation','Warning','Asterisk','Information')]   
          [string]$Icon = 'Error'   
        )   
        #Note: $Button is equl to [System.Enum]::GetNames([System.Windows.Forms.MessageBoxButtons])   
        #Note: $Icon is equl to [System.Enum]::GetNames([System.Windows.Forms.MessageBoxIcon])   
        $MessageIcon = [System.Windows.Forms.MessageBoxIcon]::$Icon   
        [System.Windows.Forms.MessageBox]::Show($Message,$Title,$Button,$MessageIcon)   
      }  

    function Get-HardwareInfo {
        [CmdletBinding()]
        param (
            [Parameter()]
            [System.String]
            $ServerName = $serverNameTextBox.Text
        )

        $cimSessionOption = New-CimSessionOption -Protocol Default
        if (!$checkBoxNoCreds.IsChecked) 
        {
            $secureStringPassword = ConvertTo-SecureString $passwordboxPassword.Password -AsPlainText -Force
            $encryptedPassword = ConvertFrom-SecureString -SecureString $secureStringPassword
            $credential = New-Object System.Management.Automation.PsCredential($textboxUserName.Text, ($encryptedPassword | ConvertTo-SecureString))
            
            try {
                $cimsession = New-CimSession -ComputerName $ServerName -SessionOption $cimSessionOption -Credential $credential -Authentication Kerberos -ErrorAction Stop
            }
            catch {
                try {
                    $cimsession = New-CimSession -ComputerName $ServerName -SessionOption $cimSessionOption -Credential $credential -ErrorAction Stop
                }
                catch {
                    
                }
                Show-MessageBox -Message "Cannot connect remote system over CIM Protocol, `nTry script locally" -Title 'Connection Error'
            }
        } #if (!$checkBoxNoCreds.IsChecked) 
        else 
        {
            try {
                $cimsession = New-CimSession -ComputerName $ServerName -SessionOption $cimSessionOption -ErrorAction Stop
            }
            catch {
                Show-MessageBox -Message "Cannot connect remote system over CIM Protocol, `nTry script locally" -Title 'Connection Error'
            }
        } #else if (!$checkBoxNoCreds.IsChecked) 

        if ($null -ne $cimsession)
        {
            $computerSystem  = Get-CimInstance -Cimsession $cimsession -ClassName CIM_ComputerSystem | Select-Object Manufacturer, Model
            $bios            = Get-CimInstance -Cimsession $cimsession -ClassName Win32_BIOS | Select-Object SerialNumber, SMBIOSBIOSVersion
            $baseBoard       = Get-CimInstance -Cimsession $cimsession -ClassName win32_baseboard | Select-Object Manufacturer, Product, SerialNumber, Version
            $operatingSystem = Get-CimInstance -Cimsession $cimsession -ClassName CIM_OperatingSystem | select-Object Caption, OSArchitecture
            $processor       = Get-CimInstance -Cimsession $cimsession -ClassName CIM_Processor | select-Object Name, OSArchitecture, NumberOfCores, NumberOfEnabledCore, NumberOfLogicalProcessors, ProcessorId, PartNumber
            $videoController = Get-CimInstance -Cimsession $cimsession -ClassName win32_VideoController | Select-Object Name, VideoProcessor
            $diskDrive       = Get-CimInstance -Cimsession $cimsession -ClassName Win32_DiskDrive | Select-Object Model, SerialNumber, Size, FirmwareRevision, InterfaceType, Index
            $networkAdapter  = Get-CimInstance -Cimsession $cimsession -ClassName Win32_NetworkAdapter -Filter "PhysicalAdapter = 'true'" | Select-Object Name, ProductName, DeviceID, Speed, AdapterType, InterfaceIndex, MACAddress
            $physicalMemory  = Get-CimInstance -Cimsession $cimsession -ClassName CIM_PhysicalMemory | ForEach-Object -Process {
                [pscustomobject]@{
                    #DeviceLocator = "" Doesn't actually exist?
                    SerialNumber  = $_.SerialNumber
                    Capacity      = $_.Capacity
                    Speed         = if ($_.speed -ge 1000000000) {"$($_.Speed / 1000000000) Gb/s"} else {"$($_.Speed / 1000000) Mb/s"}
                    PartNumber    = $_.PartNumber
                    Manufacturer  = $_.Manufacturer
                }
            }
            $monitor = Get-CimInstance -Cimsession $cimsession -ClassName WmiMonitorID -Namespace root\wmi -ErrorAction SilentlyContinue | ForEach-Object -Process {
                [pscustomobject]@{
                    ManufacturerName  = [char[]]$_.ManufacturerName -join ''
                    ProductCodeID     = [char[]]$_.ProductCodeID    -join ''
                    UserFriendlyName  = [char[]]$_.UserFriendlyName -join ''
                    SerialNumberID    = [char[]]$_.SerialNumberID   -join ''
                    YearOfManufacture = $_.YearOfManufacture
                    WeekOfManufacture = $_.WeekOfManufacture
                }
            }
        } #if ($null -ne $cimsession)

        [pscustomobject]@{
            ComputerName    = $ServerName
            computerSystem  = $computerSystem
            Bios            = $bios
            BaseBoard       = $baseBoard
            OperatingSystem = $operatingSystem
            Processor       = $processor
            PhysicalMemory  = $physicalMemory
            VideoController = $videoController
            Monitor         = $monitor
            DiskDrive       = $diskDrive
            NetworkAdapter  = $networkAdapter
        } #[pscustomobject]@{
    } #function Get-HardwareInfo {
    
    $global:allHardwareInfo =  $null
    $global:allHardwareInfo = Get-HardwareInfo -ServerName $serverNameTextBox.Text
    if ([string]::IsNullOrEmpty($global:allHardwareInfo.computerSystem))
    {
        $textBlockOS.Text = ''
        $textBlockSystemHW.Text = ''
        $textBlockMotherBoard.Text = ''
        $textBlockCpu.Text = ''
        $memorySize = ''
        $textBlockRam.Text = ''
        $textBlockGraphic.Text = ''
        $textBlockMonitor.Text =  ''
        $hddSize = ''
        $textBlockHDD.Text =  ''
        $textBlockNetwork.Text =  ''
        $exportButton.Visibility = 'Hidden'
        $checkBoxNoCreds.IsChecked = $true
    }
    else 
    {
        $textBlockOS.Text = "{0} - {1}" -f $global:allHardwareInfo.OperatingSystem.Caption, $global:allHardwareInfo.OperatingSystem.OSArchitecture
        $textBlockSystemHW.Text = "{0} {1} - Serial No: {2}" -f $global:allHardwareInfo.computerSystem.Manufacturer, $global:allHardwareInfo.computerSystem.Model, $global:allHardwareInfo.Bios.SerialNumber
        $textBlockMotherBoard.Text = "{0} - Product: {1}" -f $global:allHardwareInfo.BaseBoard.Manufacturer, $global:allHardwareInfo.BaseBoard.Product
        $textBlockCpu.Text = "{0} - {1} - Id: {2}" -f $global:allHardwareInfo.Processor.Count, $global:allHardwareInfo.Processor[0].Name, $global:allHardwareInfo.Processor[0].ProcessorId
        $memorySize = $global:allHardwareInfo.PhysicalMemory.Capacity | Measure-Object -Sum | Select-Object -ExpandProperty Sum
        $textBlockRam.Text = "{0} Gb - Serial No: {1}  Part No: {2}" -f [System.Math]::Round($memorySize/1gb), ($global:allHardwareInfo.PhysicalMemory.SerialNumber.trim() -join ', '), ($global:allHardwareInfo.PhysicalMemory.PartNumber.trim() -join ', ')
        $textBlockGraphic.Text = $global:allHardwareInfo.VideoController.Name.trim() -join ', '
        $textBlockMonitor.Text =  "{0} - Serial No: {1}" -f ($global:allHardwareInfo.Monitor.ManufacturerName -join ', ') , ($global:allHardwareInfo.Monitor.SerialNumberID -join ', ')
        $hddSize = $global:allHardwareInfo.DiskDrive.Size | Measure-Object -Sum | Select-Object -ExpandProperty Sum
        $textBlockHDD.Text =  "{0} Gb - {1} Serial No: {2}" -f [System.Math]::Round($hddSize/1gb), ($global:allHardwareInfo.DiskDrive.Model -join ', ' ), ($global:allHardwareInfo.DiskDrive.SerialNumber -join ', ' )
        $textBlockNetwork.Text =  "{0} - Mac ID: {1}" -f ($global:allHardwareInfo.NetworkAdapter.ProductName -join ', ' ), ($global:allHardwareInfo.NetworkAdapter.MACAddress -join ', ' )
        $exportButton.Visibility = 'Visible'
        $checkBoxNoCreds.IsChecked = $true
    }
})

$exportButton.Add_Click({
    function Open-FileDialog 
    {
        param (
            [string]$Path = [Environment]::GetFolderPath('Desktop')
        )
        $fileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
            InitialDirectory = $Path
            Filter = 'json (*.json)|*.json'
        }
        $null = $fileBrowser.ShowDialog()
        $fileBrowser.FileName
    }

    Function Save-FileDialog
    { 
        param (
            [string]$Path = [Environment]::GetFolderPath('Desktop')
        )
        [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

        $SaveFileDialog = New-Object System.Windows.Forms.SaveFileDialog
        $SaveFileDialog.initialDirectory = $Path
        $SaveFileDialog.filter = 'json (*.json)|*.json' #"All files (*.*)| *.*"
        $SaveFileDialog.ShowDialog() | Out-Null
        $SaveFileDialog.filename
    }

    $jsonFile = Save-FileDialog
    $allHardwareInfo | ConvertTo-Json -Depth 20 | Out-File -FilePath $jsonFile
})

[void]$form.ShowDialog()
