#Url:  http://vcloud-lab.com
#Date: 19 December 2020
#Author: Janvi

#Microsoft Azure dll login libraries
$adal = "$PSScriptRoot\dll\Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
$adalforms = "$PSScriptRoot\dll\Microsoft.IdentityModel.Clients.ActiveDirectory.WindowsForms.dll"
[void][System.Reflection.Assembly]::LoadFrom($adal)
[void][System.Reflection.Assembly]::LoadFrom($adalforms)

#Tenant and Subscription Id details
$tenantId = '3b80xxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
$subscriptionId = '9e22xxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

#Import Microsoft Azure dll login libraries and show Azure login page
$authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList "https://login.windows.net/$tenantId"
$authResult = $authContext.AcquireToken('https://management.azure.com/', '1950a258-227b-4e31-a9cf-717495945fc2', 'urn:ietf:wg:oauth:2.0:oob', 'always')

#Get Authentication Header (Expires after some time)
$authHeader = $authResult.CreateAuthorizationHeader()

#Get the list of all Microsoft Azure Storage Accounts
$params = @{
	ContentType = 'application/x-www-form-urlencoded'
	Headers	= @{
		'authorization' = $authHeader
	}
	Method = 'Get'
	URI	= "https://management.azure.com/subscriptions/$subscriptionId/providers/Microsoft.Storage/storageAccounts?api-version=2019-06-01"
}
Invoke-RestMethod @params | Select-Object -ExpandProperty value | Select-Object name, location