
# Create a hashtable for parameters
$templateParameters = @{
    rgLocation = 'eastus'
    rgName     = 'test'
}

# Set the location where the template file is stored
$templateFilePath = '.\resource_group.json'

# Deploy the ARM template
New-AzSubscriptionDeployment `
    -Location $templateParameters.rgLocation `
    -TemplateFile $templateFilePath `
    -TemplateParameterObject $templateParameters

#https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-to-subscription?tabs=azure-cli
#https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-to-resource-group?tabs=azure-cli

# Define variables for deployment
rgLocation="eastus"
rgName="test"

# Set the path to the template file
templateFilePath="./resource_group.json"

# Deploy the ARM template
az deployment sub create \
  --location $rgLocation \
  --template-file $templateFilePath \
  --parameters rgLocation=$rgLocation rgName=$rgName