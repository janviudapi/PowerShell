<?php
// Get the authenticated user's username
$authenticatedUser = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];

// Output the username
echo "Authenticated User: $authenticatedUser";

