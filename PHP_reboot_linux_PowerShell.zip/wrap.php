<?php
	    $username = isset($_POST['username']) ? $_POST['username'] : '';
		$password = isset($_POST['password']) ? $_POST['password'] : '';
		$servername = isset($_POST['servername']) ? $_POST['servername'] : '';
	
	    echo "<div id='phpBox' class='phpData' style='background-color: coral; color: white'>";
	    #$userName = shell_exec('powershell -ExecutionPolicy Unrestricted -Command $env:USERNAME');
	    echo "<h3 class='maintext' style='display: block;'>'<strong>$username</strong>' trying to submit reboot request for server '<strong>$servername</strong>'</h3>"; 
	
	    $psfileoutput = shell_exec("PowerShell -ExecutionPolicy Unrestricted -NonInteractive -File Reboot-LinuxServer.ps1 -Server $servername -UserName $username -Password $password"  );
	    echo '<div>' . $psfileoutput . '</div>';
	echo "</div>";