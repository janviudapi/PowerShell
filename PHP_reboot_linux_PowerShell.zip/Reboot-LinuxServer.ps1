param(
    [string]$Server,
	[string]$UserName,
	[string]$Password
)

$cimsession = $null

try {
	$secureString = $Password | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString
	$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName, ($secureString | ConvertTo-SecureString)
	$cimsession = New-CimSession -ComputerName $env:COMPUTERNAME -Credential $credential -ErrorAction Stop
}
catch 
{
	$error.exception.message > c:\temp\command_output.txt
	"<h3>
		Reboot job submission failed $Server `n
		The user name or password is incorrect. `n
	</h3>"
    #$htmlReport | Out-File c:\temp\logs.txt -Append
	"$server,$UserName,WrongPassword,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp\htdocs\reboot\log\reboot.log -Append
}

if ($null -ne $cimsession)
{
	echo y | plink -ssh -no-antispoof -pw ubuntu ubuntu@$server 'sudo whoami' > 'C:\xampp\htdocs\reboot\log\first_command_output.txt' 2>&1
	echo y | plink -ssh -no-antispoof -pw ubuntu ubuntu@$server 'sudo shutdown -r' > 'C:\xampp\htdocs\reboot\log\second_command_output.txt' 2>&1
	$log = Get-Content C:\xampp\htdocs\reboot\log\second_command_output.txt
	$mainMessage = $log[0].trim('plink : ') -creplace ('Shutdown','Reboot')
	$htmlReport = "<h4>Server reboot job submitted for '$Server'</h4>"
	$htmlReport += "<h3>$mainMessage</h3>"	
	if ($mainMessage -match 'scheduled')
	{
		"$server,$UserName,Scheduled,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp\htdocs\reboot\log\reboot.log -Append
	}
	elseif ($mainMessage -match 'fatal')
	{
		"$server,$UserName,Error,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp\htdocs\reboot\log\reboot.log -Append
	}
	else {
		"$server,$UserName,unknown,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp\htdocs\reboot\log\reboot.log -Append
	}
	
	$htmlReport
}

