#Load required libraries
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing 

#Load required dll libraries
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$assemblyLocation = Join-Path -Path $scriptPath -ChildPath .\binary
foreach ($assembly in (Get-ChildItem $assemblyLocation -Filter *.dll)) {
    [System.Reflection.Assembly]::LoadFrom($assembly.FullName) | out-null
}

#Read XAML form
[xml]$xaml = Get-Content "$PSScriptRoot\xaml\form.xaml"

#Load XAML form
$reader = (New-Object System.Xml.XmlNodeReader $xaml) 
$form = [Windows.Markup.XamlReader]::Load($reader) 

#Load control variables
$xaml.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]")  | ForEach-Object { 
	New-Variable  -Name $_.Name -Value $Form.FindName($_.Name) -Force 
}

#Code & Events
$ComboBox1.ItemsSource =  @('Item1','Item2','Item3')
$combobox1.SelectedItem = 'Item1'
$Image1.Source = "$PSScriptRoot\Images\Image.png"
#$DataGrid.RowBackground = 'Black'
$Datagrid.ItemsSource = Get-Service | Select-Object Name, Status, StartType -First 5
$ListBox.ItemsSource =  @('Item1','Item2','Item3')
$combobox1.SelectedItem = 'Item1'

#Mandetory last line of every script to load form
[void]$Form.ShowDialog()