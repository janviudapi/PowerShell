New-AzResourceGroupDeployment -ResourceGroupName 'vcloud-lab.com'  `
                               -TemplateFile "$PSScriptRoot\CPU_Quota_Alert_combined_template.json" `
                               -TemplateParameterFile "$PSScriptRoot\CPU_Quota_Alert_template_parameters.json" `
                               -Verbose

<#
#Another way 2: Deploy Using a Parameters File
# Variables

$resourceGroupName = "YourResourceGroupName"
$deploymentName = "QuotaAlertDeployment"
$templateFilePath = "$PSScriptRoot\CPU_Quota_Alert_combined_template.json"  # Path to your ARM template
$parametersFilePath = "$PSScriptRoot\CPU_Quota_Alert_template_parameters.json"  # Path to your parameters file

# Deploy the template
New-AzResourceGroupDeployment `
    -ResourceGroupName $resourceGroupName `
    -TemplateFile $templateFilePath `
    -TemplateParameterFile $parametersFilePath `
    -DeploymentName $deploymentName
#>