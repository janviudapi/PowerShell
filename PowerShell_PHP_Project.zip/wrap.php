<?php
	/*
	$text = $_POST['text'];
	$output = wordwrap($text, 60, "<br>");
	echo $output; 
	*/
	    $name = isset($_POST['name']) ? $_POST['name'] : '';
	
	    echo "<div id='phpBox' class='phpData' style='background-color: coral; color: white'>";
	    $userName = shell_exec('powershell -ExecutionPolicy Unrestricted -Command $env:USERNAME');
	    echo "<p class='maintext' style='display: block;'> '<strong>$userName</strong>' requested user account password reset for '<strong>$name</strong>' </p><br/>"; 
	
//    # Written By: http://vcloud-lab.com
//    # Date: 19 January 2022
//    # Env: Powershell 5.1, PHP (latest), JQuery (latest), HTML 5, CSS, XAMPP
	
	    $psfileoutput = shell_exec("PowerShell -ExecutionPolicy Unrestricted -NonInteractive -File Reset-UserPassword.ps1 -UserAccount $name");
	    echo '<pre>' . $psfileoutput . '</pre>';
	echo "</div>";
?>