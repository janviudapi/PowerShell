$fileExtension = "*.md"
$numbering = Import-Csv -Path "$PSScriptRoot\re-numbering.csv" 
$files = Get-ChildItem -Path "$PSScriptRoot\files" -File -Recurse -Include $fileExtension  #-Exclude '*.csv','*.zip','*.ps1'
$files

foreach ($file in $files) 
{
    $extractedOldNumber = $file.Name.Substring(0,2)
    #[regex]::Match($file.Name, '^\d+') # Regex example to extract leading number
    $newNumber = $numbering | Where-Object {[int]$($_.OldNumber.Trim()) -eq [int]$extractedOldNumber.Trim()} | Select-Object -ExpandProperty NewNumber
    #$oldName = $file.Name
    $newName = $file.name -replace '^\d{1,2}', $newNumber

    #oldName
    #newName

  $file | Rename-Item -NewName $newName
}
Write-Host "Renaming Completed!"
Get-ChildItem -Path "$PSScriptRoot\files" -File -Recurse -Include $fileExtension  #-Exclude '*.csv','*.zip','*.ps1'

# $files | Sort-Object { [int]$($_.BaseName) -replace '\D' }

# $files | Sort-Object -Property @{
#     Expression = { 
#         # Extract numeric part from the filename
#         # This example assumes the number is at the beginning of the filename, followed by a space
#         # Adjust the regex or splitting logic based on your specific filename pattern
#         $numbericalPart = ($_.Name -split ' ')[0]
    
#         # Convert the extracted part to an integer for numberical sorting
#         [int]$numbericalPart
#     }
# }

