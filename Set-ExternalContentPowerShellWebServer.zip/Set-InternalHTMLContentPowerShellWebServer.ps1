# HTML server URL
$url = 'http://localhost:8080/'

# HTML content to return
$html = @"
<!DOCTYPE html>
<html>
<body>
  <h1>PowerShell Web Server</h1>
  <p>Example Web Server with Http Listener</p>
</body>
</html>
"@

# Create and start the listener
$htmlListener = New-Object System.Net.HttpListener
$htmlListener.Prefixes.Add($url)
$htmlListener.Start()

Write-Host "🚀 Server started at $url (Press Ctrl+C to stop)"

# Keep the server running
while ($htmlListener.IsListening) {
    try {
        # Wait for a request
        $httpContext = $htmlListener.GetContext()
        $httpResponse = $httpContext.Response

        # Send HTML response
        $buffer = [Text.Encoding]::UTF8.GetBytes($html)
        $httpResponse.ContentLength64 = $buffer.Length
        $httpResponse.ContentType = 'text/html'
        $httpResponse.OutputStream.Write($buffer, 0, $buffer.Length)

        # Finish request
        $httpResponse.OutputStream.Close()
    } catch {
        Write-Warning "Error: $_"
    }
}

# Stop the listener (won't hit unless externally stopped)
$htmlListener.Stop()
