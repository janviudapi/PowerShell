document.addEventListener('DOMContentLoaded', function () {
    const mainForm = document.getElementById('mainFormBox');
    const infoForm = document.getElementById('showInfoBox');
    const goBackButton = document.getElementById('goBackButton');
    const processInfo = document.getElementById('processInfo');
    const typedNumber = document.getElementById('typedNumber');

    mainForm.addEventListener('submit', function (event) {
        event.preventDefault();
        processInfo.querySelectorAll('.result-text').forEach(element => element.remove());

        mainForm.style.display = 'none'; 
        infoForm.style.display = 'block';
        
        // Seperation for result display
        const spanBold = document.createElement('span');
        spanBold.className = 'result-text';
        if (typedNumber.value == '' || typedNumber.value === null || typedNumber.value === undefined) {
            spanBold.innerHTML = 'Oops ! Please type some number.&nbsp;';
        }
        else {
            spanBold.innerHTML = 'Selected number is: &nbsp;';
        }

        const spanInfo = document.createElement('span');
        spanInfo.className = 'result-text';
        spanInfo.style.fontWeight = 'bold';
        spanInfo.innerHTML = typedNumber.value;

        processInfo.insertBefore(spanBold, goBackButton);
        processInfo.insertBefore(spanInfo, goBackButton);        
    });

    goBackButton.addEventListener('click', function () {
        mainForm.style.display = 'block'; 
        infoForm.style.display = 'none';
    });
});

