$htmlDir = Join-Path $PSScriptRoot "html_content"
$networkInterfaceName = 'Wi-Fi'
$port = '8080'

$htmlFiles = @("index.html", "index.htm", "home.html", "default.html", "error.html")

$ip = Get-NetIPAddress -InterfaceAlias $networkInterfaceName -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike '169.*' } |
    Select-Object -ExpandProperty IPAddress -First 1

$url = "http://$ip`:$port/"

# Start the listener
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)
$listener.Start()

Write-Host "🌍 HTML files location: $htmlDir"
Write-Host "🚀 PowerShell Web Server: $url (Press Ctrl + C to stop) 🚀"

function Get-ContentType {
    param([string]$filename)
    switch -Wildcard ($filename) {
        "*.html" { "text/html" }
        "*.htm"  { "text/html" }
        "*.css"  { "text/css" }
        "*.js"   { "application/javascript" }
        "*.json" { "application/json" }
        "*.png"  { "image/png" }
        "*.jpg"  { "image/jpeg" }
        "*.jpeg" { "image/jpeg" }
        "*.gif"  { "image/gif" }
        "*.svg"  { "image/svg+xml" }
        default  { "application/octet-stream" }
    }
}

function Send-LogRequest {
    param($request)
    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $method = $request.HttpMethod
    $url = $request.RawUrl
    Write-Host "[$time] [$method] $url"
}

try {
    while ($listener.IsListening) {
        try {
            $context = $listener.GetContext()
            $request = $context.Request
            $response = $context.Response

            Send-LogRequest $request

            $localPath = $request.Url.LocalPath.TrimStart("/")

            # Handle custom API
            if ($localPath -like "api/*" -and $request.HttpMethod -eq "POST") {
                $reader = New-Object System.IO.StreamReader($request.InputStream)
                $body = $reader.ReadToEnd()
                Write-Host "    🔧 POST Body: $body"

                $jsonResponse = @{
                    status = "ok"
                    message = "Data received"
                    received = $body
                } | ConvertTo-Json

                $bytes = [System.Text.Encoding]::UTF8.GetBytes($jsonResponse)
                $response.ContentType = "application/json"
                $response.StatusCode = 200
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
                $response.OutputStream.Close()
                continue
            }

            if ([string]::IsNullOrWhiteSpace($localPath)) {
                $directoryFiles = Get-ChildItem $htmlDir
                $localPath = $htmlFiles | Where-Object { $_ -in $directoryFiles.Name } | Select-Object -First 1
            }

            $filePath = Join-Path $htmlDir $localPath

            if (Test-Path $filePath) {
                $bytes = [System.IO.File]::ReadAllBytes($filePath)
                $response.ContentType = Get-ContentType $filePath
                $response.ContentLength64 = $bytes.Length
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
            } else {
                $msg = "<h1>404 Not Found</h1><p>The file '$localPath' was not found.</p>"
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($msg)
                $response.StatusCode = 404
                $response.ContentType = "text/html"
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
            }

            $response.OutputStream.Close()
        } catch {
            Write-Warning "Error during request: $_"
        }

        Start-Sleep -Milliseconds 100
    }
} finally {
    $listener.Stop()
    $listener.Close()
    Write-Host "`n🛑 Server stopped."
}
