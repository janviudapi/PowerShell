var dateinfo = {
	'info' : '24 May 2022',
};

var cardsData = {
	'Compliant' : 23,
	'NonCompliant': 60,
	'CantFetch': 40,
};

var features = {
	'bashC' : 40,
	'bashN' : 80,
	'bashF' : 40,
	'dnsC' : 40,
	'dnsN' : 90,
	'dnsF' : 40,
	'ntpC' : 40,
	'ntpN' : 40,
	'ntpF' : 40,
	'ipv6C' : 40,
	'ipv6N' : 40,
	'ipv6F' : 40,
	'issuer_dnC' : 75,
	'issuer_dnN' : 40,
	'issuer_dnF' : 40,
	'sig_algoC' : 40,
	'sig_algoN' : 40,
	'sig_algoF' : 40,
	'valid_toC' : 40,
	'valid_toN' : 40,
	'valid_toF' : 48,
};