Set-Location $PSScriptRoot
$Global:CsvFile = '.\ILOList.csv'
#$Global:Cred = Get-Credential -UserName Administrator -Message 'Enter the password for the iLO devices'

$csvData = Import-Csv $csvFile | Where-Object {$_.Model -eq 'HPE'}

add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
                return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

function Login-HPEILO {
    [cmdletbinding(ConfirmImpact = 'Medium')]
    param (
        [Parameter(Mandatory=$true, HealpMessage = 'Enter the IP address of the iLO Device')]
        [string]$Ilo = '127.0.0.1',
        [Parameter(Mandatory=$true)]
        [string]$Username = 'Administrator',
        [Parameter(Mandatory=$true)]
        [string]$Password = 'xxxxxx'
    )
    # Ilo - Login
    # $username = $cred.UserName
    # $password = $cred.GetNetworkCredential().password
    $uri = "https://$Ilo/redfish/v1"
    $body = @{Username = $Username; Password = $Password} | ConvertTo-Json
    $hpeSession = Invoke-WebRequest -Uri "$uri/SessionService/Sessions" -Method Post -Body $body -ContentType 'application/json'  #-UseBasicParsing for 5.1 version
    $hpeSession
}

foreach ($csv in $csvData) 
{
    $ilo = $sv.IP

    if ($csv.Gen -eq 5)
    {
        $uri = "https://$ilo/redfish/v1/AccountService"
    }
    else
    {
        $uri = "https://$ilo/rest/v1"
    }
    try 
    {
        $hpeSession =  Login-HPEILO -Ilo $ilo -Username $csv.Username -Password $csv.Password -ErrorAction stop
        $authHeaders =  @{'X-Auth-Token' =  $hpeSession.Headers.'X-Auth-Token'}
        $adLoginSuccess = $true
        $hpeInfo = Invoke-WebRequest -Uri $uri -Method Get -Headers $authHeaders -ContentType 'application/json' -ErrorAction Stop #-UseBasicParsing for 5.1 version
        $activeDirectory = $hpeInfo.Content -ireplace ('type', 'NewType') | ConvertFrom-Json -ErrorAction Stop

    }
    catch {
        $adLoginSuccess = $false
        $activeDirectory = $null
    }

    if ($csv.Gen -eq 5)
    {
        #$activeDirectoryStatus = $activeDirectory.ActiveDirectory.ServiceEnabled
        $activeDirectoryStatus = $activeDirectory.ActiveDirectory.RemoteRoleMapping.RemoteGroup -Join ', '
    }
    else 
    {
        $activeDirectoryStatus = $activeDirectory.Oem.Hp.Session.LDAPEnabled
    }
    [PSCustomObject]@{
        Ilo = $ilo
        ADLoginSuccess = $adLoginSuccess
        ActiveDirectory = $activeDirectoryStatus
        Gen = $csv.Gen
    }
}