# ------------------------------------------------------------
# STEP 1: Define computers or IP addresses to test
# ------------------------------------------------------------
$computers = "ad001", "server1", "psdomain02", "192.168.34.39"
$port = 445
$maxThreads = 10

# ------------------------------------------------------------
# STEP 2: Create and open a runspace pool
# ------------------------------------------------------------
$runspacePool = [RunspaceFactory]::CreateRunspacePool(1, $maxThreads)
$runspacePool.Open()

$jobs = @()

# ------------------------------------------------------------
# STEP 3: Create one runspace job per computer
# ------------------------------------------------------------
foreach ($computer in $computers) {

    $ps = [PowerShell]::Create()
    $ps.RunspacePool = $runspacePool

    $null = $ps.AddScript({
        param($ComputerName, $Port)

        # ----------------------------------------------------
        # STEP 4: Define Test-TcpPort function inside runspace
        # ----------------------------------------------------
        function Test-TcpPort {
            param (
                [Parameter(Mandatory)][string]$ComputerName,
                [Parameter(Mandatory)][int]$Port,
                [int]$ConnectionTimeout = 500
            )

            # Resolve IPv4 address
            try {
                $ip = ([System.Net.Dns]::GetHostAddresses($ComputerName) |
                       Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
                       Select-Object -First 1).IPAddressToString
            } catch {
                $ip = $ComputerName
            }

            # Ping test
            try {
                $ping = New-Object System.Net.NetworkInformation.Ping
                $pingReply = $ping.Send($ip, $ConnectionTimeout)
                $pingStatus = ($pingReply.Status -eq 'Success')
            } catch {
                $pingStatus = $false
            }

            # TCP port test
            $tcpClient = New-Object System.Net.Sockets.TcpClient
            $portOpen = $false

            try {
                $async = $tcpClient.BeginConnect($ip, $Port, $null, $null)
                if ($async.AsyncWaitHandle.WaitOne($ConnectionTimeout, $false)) {
                    $tcpClient.EndConnect($async)
                    $portOpen = $true
                }
            } catch {
                $portOpen = $false
            } finally {
                $tcpClient.Dispose()
            }

            # Output result
            [pscustomobject]@{
                ComputerName         = $ComputerName
                IP                   = $ip
                PingStatus           = $pingStatus
                PortConnectionStatus = $portOpen
            }
        }

        # ----------------------------------------------------
        # STEP 5: Execute function
        # ----------------------------------------------------
        Test-TcpPort -ComputerName $ComputerName -Port $Port
    })

    $ps.AddArgument($computer) | Out-Null
    $ps.AddArgument($port) | Out-Null

    $jobs += [pscustomobject]@{
        PowerShell = $ps
        Handle     = $ps.BeginInvoke()
    }
}

# ------------------------------------------------------------
# STEP 6: Collect results and clean up
# ------------------------------------------------------------
$results = foreach ($job in $jobs) {
    try {
        $job.PowerShell.EndInvoke($job.Handle)
    } finally {
        $job.PowerShell.Dispose()
    }
}

$runspacePool.Close()
$runspacePool.Dispose()

# ------------------------------------------------------------
# STEP 7: Display output
# ------------------------------------------------------------
$results