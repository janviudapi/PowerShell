$computers = "ad001", "server1", "psdomain02", "192.168.34.39"
$port = 445

function Test-TcpPort {
    param (
        [parameter(Mandatory)][String]$ComputerName,
        [parameter(Mandatory)][Int]$Port,
        [parameter(Mandatory=$false)][Int]$ConnectionTimeout = 500
    )

    try {
        $hostEntry = [System.Net.Dns]::GetHostAddresses($ComputerName)
        # Fix: Ensure we take the first IPv4 address found
        $ip = ($hostEntry | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1).IPAddressToString
    } catch {
        $ip = $ComputerName
    }

    if (-not $ip) { $ip = $ComputerName }

    try {
        $ping = New-Object System.Net.NetworkInformation.Ping
        $pingReply = $ping.Send($ip, $ConnectionTimeout)
        $pingStatus = ($pingReply.Status -eq 'Success')
    } catch {
        $pingStatus = $false
    }

    $tcpClient = New-Object System.Net.Sockets.TcpClient
    $portConnectionStatus = $false

    try {
        $async = $tcpClient.BeginConnect($ip, $Port, $null, $null)
        if ($async.AsyncWaitHandle.WaitOne($ConnectionTimeout, $false)) {
            $tcpClient.EndConnect($async)
            $portConnectionStatus = $true
        }
    } catch {
        $portConnectionStatus = $false
    }
    finally {
        $tcpClient.Dispose()
    }

    [pscustomobject]@{
        ComputerName         = $ComputerName
        IP                   = $ip
        PingStatus           = $pingStatus
        PortConnectionStatus = $portConnectionStatus
    }
}

$initialSessionState = [InitialSessionState]::CreateDefault()
$functioDefinition = Get-Content Function:\Test-TcpPort
$addMessageSessionStateFunction = New-Object System.Management.Automation.Runspaces.SessionStateFunctionEntry -ArgumentList 'Test-TcpPort', $functioDefinition
$initialSessionState.Commands.Add($addMessageSessionStateFunction)

$runspacePool = [RunspaceFactory]::CreateRunspacePool(2, 10, $initialSessionState, $Host)
$runspacePool.ThreadOptions = "ReuseThread"
$runspacePool.Open()

$syncHash = [hashtable]::Synchronized(@{})

$scriptBlock = {
    param($ComputerName, $Port)
    $testResult = Test-TcpPort -ComputerName $ComputerName -Port $port
    $testResult
    $syncHash = $testResult
}

$jobs = foreach ($computerName in $computers) {
    $ps = [PowerShell]::Create()
    $ps.AddScript($scriptBlock.ToString())
    $ps.AddParameter('computerName', $computerName)
    $ps.AddParameter('port', $port)
    $ps.RunspacePool = $runspacePool
    New-Object PSObject -Property @{
        PowerShell = $ps
        Handle   = $ps.BeginInvoke()
    }
}

while ($jobs.Handle | Where-Object { -not $_.IsCompleted }) {
    Start-Sleep -Seconds 1
}

$results = foreach ($job in $jobs) {
    $psJob = $job.PowerShell
    $psHandle = $job.Handle

    if ($psJob) {
        $output = $psJob.EndInvoke($psHandle)
        $psJob.Dispose()
        $output
    }

}

$runspacePool.Dispose()
$ps.Dispose()

$results