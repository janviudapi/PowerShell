param(
    [string]$Server,
	[string]$UserName,
	[string]$Password
)

$cimsession = $null

# $json = @{
# 	'vcloud-lab\vmano' = @('172.17.219.117', '192.168.34.12')
# 	'vcloud-lab\janvi' = @('172.17.219.117', '192.168.34.12')
# }

# if ($username -notin $json.keys)
# {
# 	"<h3>
# 		Your user account doesn't have access to portal - $username `n
# 		Log has been recorded. `n
# 	</h3>"
# 	#$htmlReport | Out-File C:\xampp1\htdocs\reboot\log\logs.txt -Append
# 	"$server,$UserName,NoAccess,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp1\htdocs\reboot\log\reboot.log -Append
# 	return
# }

# if ($server -notin $json["$UserName"])
# {
	
# 	"<h3>
# 		You don't have access to reboot server $Server `n
# 		Log has been recorded. `n
# 	</h3>"
# 	#$htmlReport | Out-File C:\xampp1\htdocs\reboot\log\logs.txt -Append
# 	"$server,$UserName,NoAccess,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp1\htdocs\reboot\log\reboot.log -Append
# 	return
# }

try {
	$secureString = $Password | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString
	$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName, ($secureString | ConvertTo-SecureString)
	$cimsession = New-CimSession -ComputerName $env:COMPUTERNAME -Credential $credential -ErrorAction Stop
}
catch 
{
	$error.exception.message > C:\xampp1\htdocs\reboot\log\command_output.txt
	"<h3>
		Reboot job submission failed $Server `n
		The user name or password is incorrect. `n
	</h3>"
    #$htmlReport | Out-File C:\xampp1\htdocs\reboot\log\logs.txt -Append
	"$server,$UserName,WrongPassword,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp1\htdocs\reboot\log\reboot.log -Append
}

if ($null -ne $cimsession)
{
	echo y | plink -ssh -no-antispoof -pw T1s@dmin12 unixsupport@$server 'sudo whoami' > 'C:\xampp1\htdocs\reboot\log\first_command_output.txt' 2>&1
	echo y | plink -ssh -no-antispoof -pw T1s@dmin12 unixsupport@$server 'sudo shutdown -r' > 'C:\xampp1\htdocs\reboot\log\second_command_output.txt' 2>&1
	$log = Get-Content C:\xampp1\htdocs\reboot\log\second_command_output.txt
	$mainMessage = $log[0].trim('plink : ') -creplace ('Shutdown','Reboot')
	$htmlReport = "<h4>Server reboot job submitted for '$Server'</h4>"
	$htmlReport += "<h3>$mainMessage</h3>"	
	if ($mainMessage -match 'scheduled')
	{
		"$server,$UserName,Scheduled,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp1\htdocs\reboot\log\reboot.log -Append
	}
	elseif ($mainMessage -match 'fatal')
	{
		"$server,$UserName,Error,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp1\htdocs\reboot\log\reboot.log -Append
	}
	else {
		"$server,$UserName,unknown,$(Get-Date -UFormat "%m/%d/%Y_%R")" | Out-File -FilePath C:\xampp1\htdocs\reboot\log\reboot.log -Append
	}
	
	$htmlReport
}

