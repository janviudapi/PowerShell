<?php
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $servername = isset($_POST['servername']) ? $_POST['servername'] : '';

    echo "<div id='phpBox' class='phpData' style='background-color: coral; color: white'>";
    echo "<h3 class='maintext' style='display: block;'>'<strong>$username</strong>' trying to submit reboot request for server '<strong>$servername</strong>'</h3>"; 

    // Updated new code - Start

    $databseFilePath = 'dbase/userservermapping.json';
    $userServerInfo = file_get_contents($databseFilePath);
    $parsedJsonData = json_decode($userServerInfo, true);

    $userExists = false;
    $serverExists = false;

    foreach ($parsedJsonData as $user) {
        if ($user['username'] === $username) {
            $userExists = true;

            // Check if the provided server name exists for this user
            if (in_array($servername, $user['servers'])) {
                $serverExists = true;
            }
            break;
        }
    }

    $logFilePath = 'log/reboot.log'; // Correctly define the log file path
    $currentDateTime = date('m/d/Y_H:i');
    
    if (!$userExists) {
        echo "<h3 class='maintext' style='display: block;'>User '<strong>$username</strong>' is not authorized to submit reboot requests to any server.</h3>";
        $message = "{$servername},{$username},NotAuthorized,{$currentDateTime}\n";
        $result = file_put_contents($logFilePath, $message, FILE_APPEND); // Use $logFilePath
    } elseif (!$serverExists) {
        // If the user exists but the server does not, display an error message
        echo "<h3 class='maintext' style='display: block;'>User '<strong>$username</strong>' doesn't have permissions to reboot this Server '<strong>$servername</strong>'</h3>";
        $message = "{$servername},{$username},ServerNotInList,{$currentDateTime}\n";
        $result = file_put_contents($logFilePath, $message, FILE_APPEND); // Use $logFilePath
    } else {
        // If both the user and server exist, proceed with the PowerShell command
        echo "<h3 class='maintext' style='display: block;'>User '<strong>$username</strong>' is submitting a reboot request for server '<strong>$servername</strong>'.</h3>";

        // Execute the PowerShell script and capture the output
        $psfileoutput = shell_exec("PowerShell -ExecutionPolicy Unrestricted -NonInteractive -File Reboot-LinuxServer.ps1 -Server $servername -UserName $username -Password $password");
        
        // Display the PowerShell output
        echo '<div>' . $psfileoutput . '</div>';
    }

    echo "</div>";
?>
