#Load required libraries
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing 

#Website: http://vcloud-lab.com
#Written By: vJanvi
#Date: 20 Jan 2023
#Tested Environment:
    #Microsoft Windows 11, Windows 2022
    #PowerShell Version 5.1, 7

#Read xaml file
$xamlFile = "$PSScriptRoot\SideLoaders\MainWindow.xaml" #'D:\Projects\PowerShell\PatchingInfo\WpfApp1\MainWindow.xaml'
$xamlContent = Get-Content -Path $xamlFile -ErrorAction Stop

#[xml]$xaml = $xamlContent -replace 'mc:Ignorable="d"', '' -replace "x:N", 'N' -replace 'x:Class=".*?"', '' -replace 'd:DesignHeight="\d*?"', '' -replace 'd:DesignWidth="\d*?"', ''
[xml]$xaml = $xamlContent -replace 'x:Class=".*?"', '' -replace 'xmlns:d="http://schemas.microsoft.com/expression/blend/2008"', '' -replace 'mc:Ignorable="d"', ''

#Read the forms in xaml
$reader = (New-Object System.Xml.XmlNodeReader $xaml) 
$form = [Windows.Markup.XamlReader]::Load($reader) 

#AutoFind all controls
$xaml.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]")  | ForEach-Object { 
    New-Variable  -Name $_.Name -Value $form.FindName($_.Name) -Force 
}

$ImageIcon.Source = "$PSScriptRoot\SideLoaders\Get_UpdateInfo.png"
#$hardwareInfo.Content = "Hardware Info V1"

#$WebBrowserPieChart.Navigate('file:///C:/Temp/dounght%20chart/donut-chart.html')

$textBoxComputer.Text = $env:COMPUTERNAME
$textBoxComputerName.Text = $env:COMPUTERNAME

$textboxUserName.Add_GotFocus({
    if ($textboxUserName.Text -eq 'Type UserName') {
        $textboxUserName.Foreground = 'Black'
        $textboxUserName.Text = ''
    }
})
$textboxUserName.Add_LostFocus({
    if ($textboxUserName.Text -eq '') {
        $textboxUserName.Text = 'Type UserName'
        $textboxUserName.Foreground = 'Darkgray'
    }
})

$passwordboxPassword.Add_GotFocus({
    if ($passwordboxPassword.Password -eq 'Type Password') {
        $passwordboxPassword.Foreground = 'Black'
        $passwordboxPassword.Password = ''
    }
})
$passwordboxPassword.Add_LostFocus({
    if ($passwordboxPassword.Password -eq '') {
        $passwordboxPassword.Password = 'Type Password'
        $passwordboxPassword.Foreground = 'Darkgray'
    }
})

$checkBoxNoCreds.Add_Checked({
    $textboxUserName.Visibility = 'Hidden'
    $passwordboxPassword.Visibility = 'Hidden'
    $labelUserName.Visibility = 'Hidden'
    $labelPassword.Visibility = 'Hidden'
})
$checkBoxNoCreds.Add_Unchecked({
    $textboxUserName.Visibility = 'Visible'
    $passwordboxPassword.Visibility = 'Visible'
    $labelUserName.Visibility = 'Visible'
    $labelPassword.Visibility = 'Visible'
})
function Show-MessageBox {   
    param (   
      [string]$Message = "Show user friendly Text Message",   
      [string]$Title = 'Title here',   
      [ValidateRange(0,5)]   
      [Int]$Button = 0,   
      [ValidateSet('None','Hand','Error','Stop','Question','Exclamation','Warning','Asterisk','Information')]   
      [string]$Icon = 'Error'   
    )   
    #Note: $Button is equl to [System.Enum]::GetNames([System.Windows.Forms.MessageBoxButtons])   
    #Note: $Icon is equl to [System.Enum]::GetNames([System.Windows.Forms.MessageBoxIcon])   
    $MessageIcon = [System.Windows.Forms.MessageBoxIcon]::$Icon   
    [System.Windows.Forms.MessageBox]::Show($Message,$Title,$Button,$MessageIcon)   
}

$buttonAudit.Add_Click({
    $WebBrowserLoading.Visibility = 'Visible'
    $WebBrowserLoading.Navigate("file:///$PSScriptRoot/SideLoaders/loading.html")

    function Get-UpdateInfo {
        [CmdletBinding()]
        param (
            [Parameter()]
            [System.String]
            $ServerName = $textBoxComputer.Text
        )
        $cimSessionOption = New-CimSessionOption -Protocol Default
        if (!$checkBoxNoCreds.IsChecked) 
        {
            $secureStringPassword = ConvertTo-SecureString $passwordboxPassword.Password -AsPlainText -Force
            $encryptedPassword = ConvertFrom-SecureString -SecureString $secureStringPassword
            $credential = New-Object System.Management.Automation.PsCredential($textboxUserName.Text, ($encryptedPassword | ConvertTo-SecureString))
            
            try {
                $cimsession = New-CimSession -ComputerName $ServerName -SessionOption $cimSessionOption -Credential $credential -Authentication Kerberos -ErrorAction Stop
            }
            catch {
                try {
                    $cimsession = New-CimSession -ComputerName $ServerName -SessionOption $cimSessionOption -Credential $credential -ErrorAction Stop
                }
                catch {
                    
                }
                Show-MessageBox -Message "Cannot connect remote system over CIM Protocol, `nTry script locally" -Title 'Connection Error'
            }
        } #if (!$checkBoxNoCreds.IsChecked) 
        else 
        {
            try {
                $cimsession = New-CimSession -ComputerName $ServerName -SessionOption $cimSessionOption -ErrorAction Stop
            }
            catch {
                try {
                    $cimSessionOption = New-CimSessionOption -Protocol Dcom
                    $cimsession = New-CimSession -ComputerName $ServerName -SessionOption $cimSessionOption -ErrorAction Stop
                }
                catch {
                    Show-MessageBox -Message "Cannot connect remote system over CIM Protocol, `nTry script locally" -Title 'Connection Error'
                }
            }
        } #else if (!$checkBoxNoCreds.IsChecked)
    
        if ($null -ne $cimsession)
        {
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -Cimsession $cimsession
            #$uptime =  [Management.ManagementDateTimeConverter]::ToDateTime($os.LastBootUpTime)
            #$os.LastBootUpTime.DateTime
            $driveCInfo = Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DeviceID = "C:"' -Cimsession $cimsession | Select-Object DeviceId, VolumeName, @{n="TotalSizeGB";e={[System.Math]::Round($_.Size/1GB,2)}}, @{n="UsedSpaceGB";e={[System.Math]::Round(($_.Size - $_.FreeSpace)/1GB,2)}}, @{n="FreeSpaceGB";e={[System.Math]::Round($_.FreeSpace/1GB,2)}}
            $lastUpdates = Get-CimInstance -ClassName Win32_QuickFixEngineering -Cimsession $cimsession | Group-Object InstalledOn | Sort-Object -Property {$_.Name -as [datetime]} | Select-Object -Last 1
    
            [pscustomobject]@{
                ComputerName    = $ServerName
                OS              = $os.Caption
                OSLastBootTime  = $os.LastBootUpTime.DateTime
                OSUptime        = New-TimeSpan -Start (Get-Date) -End $os.LastBootUpTime.DateTime | Select-Object -ExpandProperty Hours
                DeviceID        = $driveCInfo.DeviceId
                VolumeName      = $driveCInfo.VolumeName
                TotalSizeGB     = $driveCInfo.TotalSizeGB
                UsedSpaceGB     = $driveCInfo.UsedSpaceGB
                FreeSpaceGB     = $driveCInfo.FreeSpaceGB
                Updates         = $lastUpdates
            } #[pscustomobject]@{
        } #if ($null -ne $cimsession)
    }
    
    function Format-RichTextBox {  
        #https://msdn.microsoft.com/en-us/library/system.windows.documents.textelement(v=vs.110).aspx#Propertiesshut  
        param (  
            [parameter(Position=0, Mandatory=$true, ValueFromPipelineByPropertyName=$true)]  
            [System.Windows.Controls.RichTextBox]$RichTextBoxControl,  
            [String]$Text,  
            [String]$ForeGroundColor = 'Black',  
            [String]$BackGroundColor = 'White',  
            [String]$FontSize = '12',  
            [String]$FontStyle = 'Normal',  
            [String]$FontWeight = 'Normal',  
            [Switch]$NewLine  
        )  
        $ParamOptions = $PSBoundParameters  
        $RichTextRange = New-Object System.Windows.Documents.TextRange(<#$RichTextBoxControl.Document.ContentStart#>$RichTextBoxControl.Document.ContentEnd, $RichTextBoxControl.Document.ContentEnd)  
        if ($ParamOptions.ContainsKey('NewLine')) {  
            $RichTextRange.Text = "`n$Text"  
        }  
        else {  
            $RichTextRange.Text = $Text  
        }  
        
        $Defaults = @{ForeGroundColor='Black';BackGroundColor='White';FontSize='12'; FontStyle='Normal'; FontWeight='Normal'}  
        foreach ($Key in $Defaults.Keys) {  
            if ($ParamOptions.Keys -notcontains $Key) {  
                $ParamOptions.Add($Key, $Defaults[$Key])  
            }  
        }   
        
        $AllParameters = $ParamOptions.Keys | Where-Object {@('RichTextBoxControl','Text','NewLine') -notcontains $_}  
        foreach ($SelectedParam in $AllParameters) {  
            if ($SelectedParam -eq 'ForeGroundColor') {$TextElement = [System.Windows.Documents.TextElement]::ForegroundProperty}  
            elseif ($SelectedParam -eq 'BackGroundColor') {$TextElement = [System.Windows.Documents.TextElement]::BackgroundProperty}  
            elseif ($SelectedParam -eq 'FontSize') {$TextElement = [System.Windows.Documents.TextElement]::FontSizeProperty}  
            elseif ($SelectedParam -eq 'FontStyle') {$TextElement = [System.Windows.Documents.TextElement]::FontStyleProperty}  
            elseif ($SelectedParam -eq 'FontWeight') {$TextElement = [System.Windows.Documents.TextElement]::FontWeightProperty}  
            $RichTextRange.ApplyPropertyValue($TextElement, $ParamOptions[$SelectedParam])  
        }  
    }

    $textBoxComputerName.Text = $textBoxComputer.Text
    $updateInfo = Get-UpdateInfo
    Format-RichTextBox -RichTextBoxControl $richTextBoxOSUptime -Text 'OS: ' -FontWeight Bold
    Format-RichTextBox -RichTextBoxControl $richTextBoxOSUptime -Text $updateInfo.OS 
    Format-RichTextBox -RichTextBoxControl $richTextBoxOSUptime -Text 'Last Boot Time: ' -FontWeight Bold -NewLine
    Format-RichTextBox -RichTextBoxControl $richTextBoxOSUptime -Text $updateInfo.OSLastBootTime 
    Format-RichTextBox -RichTextBoxControl $richTextBoxOSUptime -Text 'Uptime Hrs: ' -FontWeight Bold -NewLine
    $osUptime = $updateInfo.OSUptime
    $uptime = -$osUptime
    Format-RichTextBox -RichTextBoxControl $richTextBoxOSUptime -Text $uptime

    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text 'Device ID: ' -FontWeight Bold
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text $updateInfo.DeviceId
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text 'Volume Name: ' -FontWeight Bold -NewLine
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text $updateInfo.VolumeName
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text 'Total Size GB: ' -FontWeight Bold -NewLine
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text $updateInfo.TotalSizeGB
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text 'Used Space GB: ' -FontWeight Bold -NewLine
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text $updateInfo.UsedSpaceGB
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text 'Free Space GB: ' -FontWeight Bold -NewLine
    Format-RichTextBox -RichTextBoxControl $richTextBoxCDrive -Text $updateInfo.FreeSpaceGB

    $freeSpaceDegree = [Math]::Round(([Math]::Round($updateInfo.FreeSpaceGB)/[Math]::Round($updateInfo.TotalSizeGB))*100)
    $usedSpaceDegree = [Math]::Round(([Math]::Round($updateInfo.UsedSpaceGB)/[Math]::Round($updateInfo.TotalSizeGB))*100)
    #$freeSpaceDegree = 359 - $usedSpaceDegree

$chart = @"
<!DOCTYPE html>
<html lang='en'>
<head>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
  </style>
</head>
<body>
  <p><Strong>C Disk </strong>Disk Usage</p>

  <table>
    <tr>
      <td >Free</td>
      <td style='width: 70%;'>
        <div style='background-color:coral; width:$freeSpaceDegree%'>
            $freeSpaceDegree%
        </div>
      </td>
    </tr>
    <tr>
      <td>Used</td>
      <td style='width: 70%;'>
        <div style='background-color: aquamarine; width:$usedSpaceDegree%'>
            $usedSpaceDegree%
        </div>
      </td>
    </tr>
  </table>
</body>
</html>

"@
    $chart | Out-File $PSScriptRoot\SideLoaders\chart.html
    $WebBrowserPieChart.Navigate("file:///$PSScriptRoot\SideLoaders\chart.html")
   
    #$updateList = New-Object System.Collections.ArrayList
    #Build Datagrid if there
    if (-not [string]::IsNullOrEmpty($updateInfo)) {
        $latestUpdate = $updateInfo.Updates.Group | Select-Object HotFixID, InstalledBy, Description, InstalledOn, Caption
        #foreach ($update in $latestUpdate)
        #{
            #$updateList.AddRange($latestUpdate)
        #}
        $dataGridUpdates.ItemsSource = @($latestUpdate)
    }
    $WebBrowserLoading.Visibility = 'Hidden'
})
[void]$form.ShowDialog()
