#Import-Module Nutanix.Cli -Prefix Ntnx
#Import-Module Nutanix.Prism.Common -Prefix Ntnx
#Import-Module Nutanix.Prism.PS.Cmds -Prefix Ntnx
#Import-Module Posh-SSH

$prism = '192.168.34.101'
$userName = 'admin'
$password = 'Computer@123'
$csvFile = 'WINDOWS-inputparameters.csv'
$prismSecureString = ConvertTo-SecureString -String $password -Force -AsPlainText

$domainUserName = 'vjanvi'
$domainPassword = 'Computer@123'

$sourceVMUsername = 'administrator'
$sourceVMPassword = 'Computer@123'
$vmSecureString = ConvertTo-SecureString -String $sourceVMPassword -Force -AsPlainText
$vmCredential = [System.Management.Automation.PSCredential]::new($sourceVMUsername,$vmSecureString)

function Show-ProgressInfo {

    [CmdletBinding()]
    param (
        [int]
        $totalSeconds = 360
    )

    $updateIntervalSeconds = 1          # spinner refresh
    $progressIntervalSeconds = 60       # 1 minute per progress update

    $spinner = @('/', '|', '-', '\')
    $spinnerIndex = 0

    $startTime = Get-Date
    $endTime = $startTime.AddSeconds($totalSeconds)

    while ((Get-Date) -lt $endTime) {

        $elapsedSeconds = (Get-Date) - $startTime
        $elapsedSeconds = [int]$elapsedSeconds.TotalSeconds

        # Calculate progress in minutes
        $progressPercent = [math]::Min(
            [math]::Floor(($elapsedSeconds / $totalSeconds) * 100),
            100
        )

        $elapsedMinutes = [math]::Floor($elapsedSeconds / 60)

        $spinChar = $spinner[$spinnerIndex % $spinner.Count]
        $spinnerIndex++

        Write-Host -NoNewline "`r$spinChar Running... $elapsedMinutes minute(s) elapsed | Progress: $progressPercent%"

        Start-Sleep -Seconds $updateIntervalSeconds
    }

    Write-Host "`r✔ Completed: 6 minutes elapsed | Progress: 100%  
}


$ntnxConnection = Connect-NTNXCluster -Server $prism -UserName $userName -Password $prismSecureString -AcceptInvalidSSLCerts -ForcedConnection
#Connect-NutanixV3PrismServer #Disconnect-NutanixV3PrismServer Connect-NtnxPrismCentral 
Write-Host "$((Get-Date).DateTime) | Server: $($ntnxConnection.Server) | IsConnected: $($ntnxConnection.IsConnected) | UserName: $($ntnxConnection.UserName)"

$currentPath = $PSScriptRoot
$csvInfo = Import-Csv -Path $currentPath\$csvFile

foreach ($row in $csvInfo)
{
    $sourceVMName = $row.SourceVMName
    $sourceVM = Get-NTNXVM | Where-Object {$_.vmName -eq $sourceVMName }
    $newVMName = $row.NewVMName
    Write-Host "$((Get-Date).DateTime) | SourceVM: $sourceVMName | isFound: Yes"

    $cloneSpec = New-NTNXObject -Name VMCloneSpecDTO 
    $cloneSpec.name = $newVMName

    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isCloning: Yes"
    Clone-NTNXVirtualMachine -vmId $sourceVM.VmId -SpecList $cloneSpec | Out-Null

    $cloneTask = Get-NTNXTask | Where-Object {($_.operationType -match 'VmClone|SnapshotCreate') -or ($_.progressStatus -eq 'VmClone')}
    While ($cloneTask)
    {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | OperationType: $($cloneTask.operationType[0]) | ProgressStatus: $($cloneTask.progressStatus[0])"
        $cloneTask = Get-NTNXTask | Where-Object {($_.operationType -match 'VmClone|SnapshotCreate') -or ($_.progressStatus -eq 'VmClone')}
        #$cloneTask | Select-Object operationType, progressStatus
        Start-Sleep -Seconds 10
    }
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isCloned: Yes"
    
    #Write-Host "PowerOn VM: $newVMName"
    $createdVM = Get-NTNXVM | Where-Object {$_.vmName -eq $newVMName }
    $powerOnTask = Set-NTNXVMPowerOn -VmId $createdVM.vmId
    While (Test-Connection -ComputerName $row.SourceVMIP -Count 1 -Quiet )
    {
        #$powerOnTask
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isPoweredOn: Running"
        Start-Sleep -Seconds 15
    }
    Start-Sleep -Seconds 10
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isPoweredOn: Completed"

    Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | PrepareUnattend: Running"
    $unattendEntries = @{
        HOSTNAME = $row.NewVMName #'ritesh1'
        ETHCONTROLLERNAME = $row.SourceVMEthName #'Ethernet'
        IPV4ADDRESSLASHSSUBNET = "$($row.NewVMIP)/$($row.NewVMSubnet)"  #'172.17.218.168/22'
        IPV4GATEWAY = $row.NewVMGateway #'172.17.216.1' 
        ADMINUSERNAME = $sourceVMUsername
        ADMINPASSWORD = $sourceVMPassword
    }

    if (Test-Path -Path $currentPath\suppliments\unattend.xml)
    {
        Remove-Item -Path $currentPath\suppliments\unattend.xml -Force
    }

    $unattend = Get-Content $currentPath\suppliments\template-unattend.xml
    foreach ($entry in $unattendEntries.keys)
    {
        $unattend = $unattend.Replace($entry, $unattendEntries[$entry])
    }
    $unattend | Out-File -FilePath $currentPath\suppliments\unattend.xml -Encoding utf8
    Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | PrepareUnattend: Completed"

    Start-Sleep -Seconds 90

    try {
        Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | OpenSession: Running | RemoteCommand: Running"
        $oldIPSession = New-PSSession -ComputerName $row.SourceVMIP -Credential $vmCredential -ErrorAction Stop
        $initialConf = Invoke-Command -Session $oldIPSession -ScriptBlock {
            if (-not (Test-Path -Path C:\Temp))
            {
                New-Item -Path C:\ -Name Temp -ItemType Directory -Force
            }
            New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -PropertyType String -Name LegalNoticeCaption -Value '' -Force
            New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -PropertyType String -Name LegalNoticeText -Value '' -Force
            #reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v LegalNoticeCaption /t REG_SZ /d ""
            #reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v LegalNoticeText /t REG_SZ /d ""
        }
        $initialConf | Out-Null #| Select-Object  PSComputerName, PSPath
        Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | OpenSession: Completed | RemoteCommand: Completed"
    }
    catch {
        Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | OpenSession: Failed | RemoteCommand: Failed"
    }
    Start-Sleep -Seconds 15

    Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | OpenRDP: Running"
    cmdkey /generic:$($row.SourceVMIP) /user:$sourceVMUsername /pass:$sourceVMPassword
    #to support rdp without certificate warning
    #HKEY_CURRENT_USER\Software\Microsoft\Terminal Server Client >> New DWORD (32-bit) >> Value Name AuthenticationLevelOverride >> Value data to 0 (zero)
    mstsc /v:$($row.SourceVMIP) 
    Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | OpenRDP: Completed"
    Start-Sleep -Seconds 30
    
    Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | UnattendPushed: Running"
    Copy-Item -Path $currentPath\suppliments\unattend.xml -Destination C:\Temp -ToSession $oldIPSession
    Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | UnattendPushed: Completed | BatchPushed: Running | LoggedInUserFound: Running"

    try {
        $remoteLoggedInUsers = Invoke-Command -Session $oldIPSession -ScriptBlock {
            'C:\Windows\System32\Sysprep\Sysprep.exe /generalize /reboot /oobe /unattend:C:\Temp\unattend.xml' > C:\Temp\generalize.bat
            quser
        } -ErrorAction Stop
        $loggedInUserId = ($remoteLoggedInUsers[1] -Split '\s+')[3]
        Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | BatchPushed: Yes | LoggedInUserFound: Yes" 
    }
    catch {
        Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | LoggedInUserFound: No" -BackgroundColor DarkRed
        return
    }

    Write-Host "$((Get-Date).DateTime) | ClonedNewVM: $newVMName | Sysprep: Running"
    #PsExec.exe \\$($oldIPSession.ComputerName) -u Administrator -p 's#rT9012' -accepteula -nobanner -i 1 -d -c -f $currentPath\suppliments\generalize.bat
    PsExec.exe \\$($oldIPSession.ComputerName) -u $sourceVMUsername -p $sourceVMPassword -accepteula -nobanner -n 120 -i $loggedInUserId -c -f $currentPath\suppliments\generalize.bat
    #Start-Sleep -Seconds 360
    Show-ProgressInfo -totalSeconds 360
    Write-Host "$((Get-Date).DateTime) | PreparedNewVM: $newVMName | Sysprep: Completed"

    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | PingTest: Running" 
    if (Test-Connection -ComputerName $row.SourceVMIP -Quiet -Count 1)
    {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | Source IP $($row.SourceVMIP) still reachable ... halting" -BackgroundColor DarkRed
        return
    }
    if (Test-Connection -ComputerName $row.NewVMIP -Quiet -Count 2)
    {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | New IP $($row.SourceVMIP) reachable"
    }
    else {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | New IP $($row.SourceVMIP) unreachable ... halting" -BackgroundColor DarkRed
        return
    }
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | PingTest: Completed"

   Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | PrepareDominJoinScript: Running"
    "`$userName = '$domainUsername'" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1"
    "`$password = '$domainPassword'" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "# create secure string from plain-text string" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "`$secureString = ConvertTo-SecureString -AsPlainText -Force -String `$password" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "# convert secure string to encrypted string (for safe-ish storage to config/file/etc.)" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "`$encryptedString = ConvertFrom-SecureString -SecureString `$secureString" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "# convert encrypted string back to secure string" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "`$secureString = ConvertTo-SecureString -String `$encryptedString" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append 
    "# use secure string to create credential object" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "`$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList `$userName,`$secureString" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    "Add-Computer -DomainName majesco.com -Credential `$credential #-Restart -Force" | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    '$error[0].Exception.Message | Out-File -FilePath c:\temp\errors.log' | Out-File -FilePath "$currentPath\suppliments\Join-Domain.ps1" -Append
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | PrepareDominJoinScript: Completed"

    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | OpenNewSession: Running | CopyFileRemotely: Running"
    $newIPSession = New-PSSession -ComputerName $row.NewVMIP -Credential $vmCredential -ErrorAction Stop    
    $newVMDetails = Copy-Item -Path $currentPath\suppliments\Join-Domain.ps1 -Destination C:\Temp -ToSession $newIPSession
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | OpenNewSession: Completed | CopyFileRemotely: Completed"

    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | RemoteDomainJoin: Running"
    $domainJoin = Invoke-Command -Session $newIPSession -ScriptBlock {    
        & 'C:\temp\Join-Domain.ps1'
        Restart-Computer -Force
    }
    $domainJoin | Out-Null
    #Restart-Computer -ComputerName $row.NewVMIP -Credential $vmCredential -Force
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | RemoteDomainJoin: Completed | Cleanup: Running"
    cmdkey /delete:$($row.SourceVMIP)
    try {
            Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | RemoteCleanup: Running"
            #$newIPSession = New-PSSession -ComputerName $row.NewVMIP -Credential $vmCredential -ErrorAction Stop
            $cleanup = Invoke-Command -Session $newIPSession -ScriptBlock {    
                Remove-Item -Path C:\Temp\* -Recurse -Force
            }
            $cleanup | Out-Null
    }
    catch {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | OpenNewSession: Failed | RemoteCommand: Failed"
    }
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | Cleanup: Completed"

        
}