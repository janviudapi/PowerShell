cd C:\Windows\System32\Sysprep
C:\Windows\System32\Sysprep\Sysprep.exe /generalize /reboot /oobe /unattend:C:\Temp\unattend.xml