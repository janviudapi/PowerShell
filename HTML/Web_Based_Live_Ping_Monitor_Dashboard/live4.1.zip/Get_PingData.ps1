#<#
Clear-Host
$notExist = $true
$pingIteration = 1
do {
    Write-Host -ForegroundColor Cyan "- Ping Interation: $pingIteration"
    $serverList = Get-Content $PSScriptRoot\Pinglist.txt | Select-Object -Unique #'thor', 'testvm', 'marvel', 'ironman' ,'superman', 'dccomics'
    Get-Job | Remove-Job -Force -Confirm:$false

    $serverList | ForEach-Object { #-ThrottleLimit 10 -Parallel {
        $null = Start-ThreadJob {
            #$argServerName = $args[0]
            try {
                $pingTest = Test-Connection -TargetName $args[0] -Count 1 -ErrorAction Stop
                [PSCustomObject]@{
                    #New-Object psobject -Property[ordered]@{ 
                    id = $pingTest.Destination
                    name = $pingTest.Destination
                    ipAddress = ($null -ne $pingTest.Address) ? $pingTest.Address.IPAddressToString : $pingTest.Destination
                    status = ($pingTest.Status.ToString() -eq 'Success') ? 'on' : 'off'
                } #[PSCustomObject]@{
            } #try {
            catch {
                [PSCustomObject]@{
                    id = $args[0]
                    name = $args[0]
                    ipAddress = 'Unknown'
                    status = 'unknown'
                }
            } #catch {
            finally {}
        } -ArgumentList $_.Trim() -ThrottleLimit 10 #$null = Start-ThreadJob
    } #$serverList | ForEach-Object {

    Start-Sleep -Seconds 2
    $report = Get-Job | Wait-Job | Receive-Job #| Select-Object @{N='id'; E={$_.Destination}}, @{N='name'; E={$_.Destination}}, @{N='ipAddress'; E={$_.Address.IPAddressToString}}, @{N='status'; E={($_.Status -eq 'Success') ? 'On' : 'Off'}} #Using the ternary operator syntax
    $report | ConvertTo-Json | Out-File $PSScriptRoot\dbase\report.json
    $pingIteration++
} while (
    # Condition that stops the loop if it returns false 
    $notExist -eq $true
) #while (
#>