function fetchDataAndRefresh() {

    // Fetch JSON data report
    fetch('dbase/report.json?timestamp=${Date.now()}', {
            cache: 'no-store' // Set cache to 'no-store' to prevent caching
        })
        //.then(response => response.json())
        .then(response => {
            // Create a new Headers object and set cache control headers
            const headers = new Headers(response.headers);
            headers.append('Cache-Control', 'no-cache, no-store, must-revalidate');
            headers.append('Pragma', 'no-cache');
            headers.append('Expires', '0');
    
            // Create a new Response object with updated headers
            const updatedResponse = new Response(response.body, {
                status: response.status,
                statusText: response.statusText,
                headers: headers
            });
    
            return updatedResponse.json();
        })
        .then(jsonData => {
            // Create desk boxes dynamically
            const dashboardElement = document.querySelector('.dashboard');
            dashboardElement.innerHTML = '';
    
            jsonData.forEach((desk) => {
                const deskElement = document.createElement('div');
                deskElement.classList.add('desk');
                deskElement.id = desk.id;
    
                const deskName = document.createElement('div');
                deskName.classList.add('desk-name');
                deskName.textContent = desk.name;
                deskName.style.marginBottom = "10px";
                deskElement.appendChild(deskName);            
    
                const deskIcon = document.createElement('img');
                deskIcon.src =  'img/system.png'
                deskIcon.width = 64
                deskIcon.height = 56
                deskElement.appendChild(deskIcon);
    
                //font-awoome example
                //const deskIcon = document.createElement('i');
                //deskIcon.classList.add('fas', 'fa-desktop', 'desk-icon');
                //deskElement.appendChild(deskIcon);
    
                const deskInfo = document.createElement('div');
                deskInfo.classList.add('desk-info');
                deskInfo.id = `${desk.id}Info`;
                deskElement.appendChild(deskInfo);
    
                const deskStatus = document.createElement('div');
                deskStatus.classList.add('status');
                deskStatus.id = `${desk.id}Status`;
                deskElement.appendChild(deskStatus);
    
                dashboardElement.appendChild(deskElement);
    
                updateDeskStatus(desk.id, desk.status);
            });
    
            // Update the desk status and info
            function updateDeskStatus(deskId, status) {
                const deskStatus = document.getElementById(`${deskId}Status`);
                const deskInfo = document.getElementById(`${deskId}Info`);
    
                if (status === 'on') {
                    deskStatus.classList.add('status-on');
                    deskStatus.classList.remove('status-off');
                    deskStatus.classList.remove('status-unknown');
                    deskInfo.textContent = 'Online';
                }   else if (status === 'off') {
                    deskStatus.classList.add('status-off');
                    deskStatus.classList.remove('status-on');
                    deskStatus.classList.remove('status-unknown');
                    deskInfo.textContent = 'Offline';
                } 
                else {
                    deskStatus.classList.add('status-unknown');
                    deskStatus.classList.remove('status-on');
                    deskStatus.classList.remove('status-off');
                    deskInfo.textContent = 'Unknown';
                }
            }
    
            // Bind data to desks
            jsonData.forEach((desk) => {
                const deskElement = document.getElementById(desk.id);
                deskElement.addEventListener('mouseenter', () => {
                    const deskInfo = document.getElementById(`${desk.id}Info`);
                    deskInfo.setAttribute('style', 'white-space: pre;');
                    deskInfo.textContent = `${desk.id}\n`
                    deskInfo.textContent += `HostName: ${desk.name}\nIP: ${desk.ipAddress}`;
                });
                deskElement.addEventListener('mouseleave', () => {
                    const deskInfo = document.getElementById(`${desk.id}Info`);
                    if (desk.status === 'on') {
                        deskInfo.textContent = 'Online';
                    } else if (desk.status == 'off') {
                        deskInfo.textContent = 'Offline';
                    } else {
                        deskInfo.textContent = 'Unknown';
                    }
                });
            });
    
            // Refresh the data again after a certain time (e.g., 5 seconds)
            setTimeout(fetchDataAndRefresh, 2000);
        }) //.then(jsonData => {
        .catch(error => {
            console.error('Error fetching JSON data:', error);
    
            // Retry the data fetch after a certain time (e.g., 5 seconds)
            setTimeout(fetchDataAndRefresh, 2000);
        }); //.catch(error => {
    } //function fetchDataAndRefresh() {
    
    // Start the initial fetch and refresh
    fetchDataAndRefresh();
    