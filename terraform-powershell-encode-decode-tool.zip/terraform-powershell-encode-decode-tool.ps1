#    .NOTES
#    --------------------------------------------------------------------------------
#     Generated on:            13-Sep-25 8:15 PM
#     Generated for:           Terrafrorm Encode/Decode String
#     PowerShell Version:      V7
#    --------------------------------------------------------------------------------
#    .DESCRIPTION
#        vcloud-lab.com Terraform Encode/Decode String

$assemblies = ('System.Windows.Forms', 'System.Data', 'System.Drawing', 'PresentationFramework')
$assemblies | Foreach-Object {[void][reflection.assembly]::Load($_)}
Add-Type -AssemblyName "System.Drawing", "System.Windows.Forms", "System.Data", "System.Design", "PresentationFramework"

[System.Windows.Forms.Application]::EnableVisualStyles()
$formEncodeDecodeString = New-Object 'System.Windows.Forms.Form'
$richtextbox = New-Object 'System.Windows.Forms.RichTextBox'
$statusstrip = New-Object 'System.Windows.Forms.StatusStrip'
$picturebox = New-Object 'System.Windows.Forms.PictureBox'
$textboxOutput = New-Object 'System.Windows.Forms.TextBox'
$buttonEncode = New-Object 'System.Windows.Forms.Button'
$radiobuttonDecode = New-Object 'System.Windows.Forms.RadioButton'
$radiobuttonEncode = New-Object 'System.Windows.Forms.RadioButton'
$textboxInput = New-Object 'System.Windows.Forms.TextBox'
$labelStringToEncode = New-Object 'System.Windows.Forms.Label'
$toolstripstatuslabel = New-Object 'System.Windows.Forms.ToolStripStatusLabel'
$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'

$radiobuttonEncode_CheckedChanged={
    $labelStringToEncode.Text = 'String to Encode:'
    $buttonEncode.Text = 'Encode'
    $textboxInput.Text = 'Password123!'
    $textboxOutput.Text = 'UGFzc3dvcmQxMjMh'
}

$radiobuttonDecode_CheckedChanged={
    $labelStringToEncode.Text = 'String to Decode:'
    $buttonEncode.Text = 'Decode'
    $textboxInput.Text = 'UGFzc3dvcmQxMjMh'
    $textboxOutput.Text = 'Password123!'
}

$buttonEncode_Click={
    if ($radiobuttonEncode.Checked)
    {
        $originalString = $textboxInput.Text  #"Password123!"
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($originalString)
        $encodedString = [System.Convert]::ToBase64String($bytes)
        #Write-Host "Encoded String (UTF8): $encodedString"
        $textboxOutput.Text = $encodedString
    }
    
    if ($radiobuttonDecode.Checked)
    {
        $error.Clear()
        try {
            $encodedString = $textboxInput.Text.Trim() #"UGFzc3dvcmQxMjMh" # Base64 for "Password123!" (UTF8)
            $decodedBytes = [System.Convert]::FromBase64String($encodedString)
            $decodedString = [System.Text.Encoding]::UTF8.GetString($decodedBytes)
            #Write-Host "Decoded String (UTF8): $decodedString"
            $textboxOutput.Text = $decodedString
        }
        catch {
            $textboxOutput.Text = 'Error: Invalid encoded string provided!'
        }
    }
}

$Form_StateCorrection_Load=
{
    $formEncodeDecodeString.WindowState = $InitialFormWindowState
}

$Form_Cleanup_FormClosed=
{
    try
    {
        $buttonEncode.remove_Click($buttonEncode_Click)
        $radiobuttonDecode.remove_CheckedChanged($radiobuttonDecode_CheckedChanged)
        $radiobuttonEncode.remove_CheckedChanged($radiobuttonEncode_CheckedChanged)
        $formEncodeDecodeString.remove_Load($formEncodeDecodeString_Load)
        $formEncodeDecodeString.remove_Load($Form_StateCorrection_Load)
        $formEncodeDecodeString.remove_FormClosed($Form_Cleanup_FormClosed)
    }
    catch { 
        Out-Null 
    }
    $formEncodeDecodeString.Dispose()
    $labelStringToEncode.Dispose()
    $textboxInput.Dispose()
    $radiobuttonEncode.Dispose()
    $radiobuttonDecode.Dispose()
    $buttonEncode.Dispose()
    $textboxOutput.Dispose()
    $picturebox.Dispose()
    $statusstrip.Dispose()
    $toolstripstatuslabel.Dispose()
    $richtextbox.Dispose()
}

$formEncodeDecodeString.SuspendLayout()
$picturebox.BeginInit()
$statusstrip.SuspendLayout()

$formEncodeDecodeString.Controls.Add($richtextbox)
$formEncodeDecodeString.Controls.Add($statusstrip)
$formEncodeDecodeString.Controls.Add($picturebox)
$formEncodeDecodeString.Controls.Add($textboxOutput)
$formEncodeDecodeString.Controls.Add($buttonEncode)
$formEncodeDecodeString.Controls.Add($radiobuttonDecode)
$formEncodeDecodeString.Controls.Add($radiobuttonEncode)
$formEncodeDecodeString.Controls.Add($textboxInput)
$formEncodeDecodeString.Controls.Add($labelStringToEncode)
$formEncodeDecodeString.AutoScaleDimensions = New-Object System.Drawing.SizeF(8, 17)
$formEncodeDecodeString.AutoScaleMode = 'Font'
$formEncodeDecodeString.ClientSize = New-Object System.Drawing.Size(467, 348)
$formEncodeDecodeString.FormBorderStyle = 'FixedDialog'
$formEncodeDecodeString.Name = 'formEncodeDecodeString'
$formEncodeDecodeString.Text = 'Encode/Decode String for Terraform'
$formEncodeDecodeString.add_Load($formEncodeDecodeString_Load)

$richtextbox.Location = New-Object System.Drawing.Point(13, 131)
$richtextbox.Margin = '4, 4, 4, 4'
$richtextbox.Name = 'richtextbox'
$richtextbox.ReadOnly = $True
$richtextbox.Size = New-Object System.Drawing.Size(435, 176)
$richtextbox.TabIndex = 8
$richtextbox.Text = 'How to encode and decode string in Terraform?

To encode string use below function:
base64encode("Password123!")     # Output: UGFzc3dvcmQxMjMh

To decode string use below function:
textdecodebase64("UGFzc3dvcmQxMjMh")     # Output: Password123!
'
[void]$statusstrip.Items.Add($toolstripstatuslabel)
$statusstrip.Location = New-Object System.Drawing.Point(0, 323)
$statusstrip.Name = 'statusstrip'
$statusstrip.Padding = '1, 0, 19, 0'
$statusstrip.Size = New-Object System.Drawing.Size(467, 25)
$statusstrip.TabIndex = 7
$statusstrip.Text = 'statusstrip'

$ImageString = @"
iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACx
jwv8YQUAAAAJcEhZcwAAAdcAAAHXAYySCGgAAAAZdEVYdFNvZnR3YXJlAHd3dy5pbmtzY2FwZS5v
cmeb7jwaAAAHaUlEQVR4Xu1bB4wVRRh+iLHEHgsKd/P/s7N3x3EFDDEIeAiIIE2O3gldJELgQCC0
KFGKlENAUIII0g4IRZBuTqWDxkIJOZVEDE0IPaDUMf/szt6+3Qcc3t177+B9yRfuL7Nv5ntTl3mB
QAwxxPB/IRirLISId/tSUlIe4Iy/Tv9qX1J8fNkExCraZow9ZSLWdAoFAgEezzMSyyY+o+24uLiH
DWbUqRkI3K99AqAa57yMYwsRT3XQdtghAP8VgGvdPgOgnQCUJuOtXL6lAvAaIj6kyiGOoxzOeRLZ
iXFx5cg2gE/TZQTjPSwfNFTPMIwnBOANgTjXyQFcR3XQdrhRiiooAHPdTgOgq/Iz3snxIa4iX1JS
0mNkC8TJtgAVyTbj44UtwCxdRjDexxagubKFeE49F3GxkwOYSz6qi/aFE8UqgAm8u/V8qK+eYfWA
64LhHJ0jANcIwEvaDjeKVQCaQxI4rxEIBEprH4139zwBAC9wztO1HXYIgC0C+Idun4HYhRpjMt7R
5VMCpDyb8qgqx3gnE/CAbkwoATSo6ycyZiAiusVwISLd/6agxhgA85IAuONjvIUAmBKcmY+bCFCK
xrvdyzSPmIxV0AmC4QwBmOcqE16YAFXdDS0oypcr97SJWE/bajmjXgM43fHREmv5fhGInwnARdbQ
wk+dnCiYBC/TUuT1mwBDDYYbBMAmRYZzaC+gE0zEsdYwyf82DYAGNKYdmxl1rG+djyC7xKwC9M16
uq1F1/ptAE6yvl140V3WjRIrQIhVoLTdkG/yc4IFoF0fLWlBm6d7SYBQk2BMgLtZAAHwkfLFi1Sy
Oedglcmf4Q3GXlOiMBxJNiI+f9cIQIcfk/EOgUDgPqccYlt7s6NgiQJX7ZXmtAA8r3oN4ns6xxbg
RqQEUMsZnf7cvoIIoEHHW5PxlkQBUMu70yNRDIbfC+A/CoAfDOCfpJcp84gnPtpdJuIwEZvYPeNv
AXjQZlDXJdDO0M5zL5VL3DlRD4H4sUDs7PbRCwy1RWX4m0uAXH321zABTwnAwwbDwUQBuJ9Oe7Qk
UpzGvAmwmnqJXaS0YJjj7nEG4tuhzg9hQ6g5oKAQgBcF4m6XvZyeh4hPkp2/CsAwFY/CVSCkAPY+
vz+99tI+0zQfd9uEggvAh6t4SRGAhgT53V3VZLhLAO4LygO8SH6XXTIEoBcQ9A3rA40APER/a9I7
QvLT+HX8arzDBU/eFQF41GXnqXIMs5XNMMdu8GYrbk2a9B7BVeaQ8ll2fyPOSPPWt0ghAAaYyK/b
DY86Ut1MgCxvvYsEdHSlD6havYacumKdzNm5J6pIdXq5Wgb1mGsJAMne+hcaJkBvUnnyklVy1wUZ
lcxe/JXqCbQ8eutfaNChhB7++aatvg+OFlLdrOFgHaCKFDEBYgL4BRg4eoJs17N3EEdOnaliO8/f
kL0GDffF75S9Bo9Qz6Jnjpwy0xd/d8zEyAlQPaOmbylq2Kylim0+cUmmp6b74nfKiumV5JaT/6hn
NmjawhfPeLV25ATYceaqzD1yNog7zl134ttOX/HF75T0DOfzzl33xakOERMg2hgTICZATIDwCtCq
cw9JZwM3u2cNVrHtZ67K+k2a++Jeduufn98gs4UvTjM/xSiHcr3x1l16Rk6Alp27+yqkG0Sz9xtv
NvPFvezWb9AtBSOfI0C/Qb44fQkREyDaeM8LsOHgcVm3cdNL3htoRYKSIIDN4rkwURIEoLnig1lf
HqP3h976FxqhBNhx9pp/a3q7rfDRc0GVpn2+N2frqcu+xhWEc77dqeYAA3GIt/6FRigBXqlRy3c4
qdsoU8W+O35BplZI9cWJPQcOVTmLd+2VCUL44slJ5dV49jbwdgz7JJg1apzMbNM+iEMmTFUx6h1d
+g7wxTPbdlCvrihn458nZZuub/lyOvTq45wA74RhFyDaeNcLsO73Y/Kj+UvlsMkzQpJ2oXetANNX
bZQVkiv45ovQ5O94619oRFIAWjnSUtNlckq6bDZxvuy4aGsQ28/LlWlVMnTjv3ZfsS8yhBKAuqT3
PyhoYtPx1QcO+eJEWiF0zrKf83zxFXsPBgkwa8Nm1biGI6fIrDwZxH77LsvqrbtajWe4Xl/JL3KE
EqBy5Zd83a92vQYqtvnERZkoTF+c2LXvQJWzcPuvvpjmmrzDzudMXLRC+ZpnLwpu/P4rsnqb7ipG
FzP13YJiQSgBJsxfJvuPGhvEaSvXO/H3Z3zhixMXbPvJFumSHDx+ii8+dPJ0tYzeSoCwNp4QSoBw
0StA2BtPiBYBItJ4QjQI0HT83KDGF9uEFwr6hxCjZy/wVbC4OSlnpWp0cmolPUmuC2vjCWY5M85E
42JaSpocNC5bjpm9UI6dkyM3/XVKVZKWM/J5uXzPHypOyyPle+MFIb1msxsemcZrmIw3TjDEWVdl
ZNaosQd2n5drGzVrfdzt18xs0/4oxfuMGKWuwBSSkWu8Bt34onu8dLuTftJGv+YiP/2uR9/6dJOu
vFKcbolRvjdeUArETNM0H/TWJ4YYYigU/gP24kGZ+h2qtAAAAABJRU5ErkJggg==
"@
$System_IO_MemoryStream = [System.IO.MemoryStream][System.Convert]::FromBase64String($ImageString)

$picturebox.Image = [System.Drawing.Image]::FromStream($System_IO_MemoryStream)
$System_IO_MemoryStream = $null

$picturebox.Location = New-Object System.Drawing.Point(371, 23)
$picturebox.Margin = '4, 4, 4, 4'
$picturebox.Name = 'picturebox'
$picturebox.Size = New-Object System.Drawing.Size(77, 66)
$picturebox.TabIndex = 6
$picturebox.TabStop = $False

$textboxOutput.Font = [System.Drawing.Font]::new('Microsoft Sans Serif', '12')
$textboxOutput.Location = New-Object System.Drawing.Point(13, 93)
$textboxOutput.Margin = '4, 4, 4, 4'
$textboxOutput.Name = 'textboxOutput'
$textboxOutput.ReadOnly = $True
$textboxOutput.Size = New-Object System.Drawing.Size(435, 30)
$textboxOutput.TabIndex = 5
$textboxOutput.Text = 'UGFzc3dvcmQxMjMh'
$textboxOutput.TextAlign = 'Center'

$buttonEncode.Location = New-Object System.Drawing.Point(263, 54)
$buttonEncode.Margin = '4, 4, 4, 4'
$buttonEncode.Name = 'buttonEncode'
$buttonEncode.Size = New-Object System.Drawing.Size(100, 30)
$buttonEncode.TabIndex = 4
$buttonEncode.Text = 'Encode'
$buttonEncode.UseVisualStyleBackColor = $True
$buttonEncode.add_Click($buttonEncode_Click)

$radiobuttonDecode.Location = New-Object System.Drawing.Point(107, 54)
$radiobuttonDecode.Margin = '4, 4, 4, 4'
$radiobuttonDecode.Name = 'radiobuttonDecode'
$radiobuttonDecode.Size = New-Object System.Drawing.Size(86, 31)
$radiobuttonDecode.TabIndex = 3
$radiobuttonDecode.Text = 'Decode'
$radiobuttonDecode.UseVisualStyleBackColor = $True
$radiobuttonDecode.add_CheckedChanged($radiobuttonDecode_CheckedChanged)

$radiobuttonEncode.Checked = $True
$radiobuttonEncode.Location = New-Object System.Drawing.Point(13, 54)
$radiobuttonEncode.Margin = '4, 4, 4, 4'
$radiobuttonEncode.Name = 'radiobuttonEncode'
$radiobuttonEncode.Size = New-Object System.Drawing.Size(86, 31)
$radiobuttonEncode.TabIndex = 2
$radiobuttonEncode.Text = 'Encode'
$radiobuttonEncode.UseVisualStyleBackColor = $True
$radiobuttonEncode.add_CheckedChanged($radiobuttonEncode_CheckedChanged)

$textboxInput.ImeMode = 'NoControl'
$textboxInput.Location = New-Object System.Drawing.Point(138, 23)
$textboxInput.Margin = '4, 4, 4, 4'
$textboxInput.Name = 'textboxInput'
$textboxInput.Size = New-Object System.Drawing.Size(225, 23)
$textboxInput.TabIndex = 1
$textboxInput.Text = 'Password123!'

$labelStringToEncode.AutoSize = $True
$labelStringToEncode.Location = New-Object System.Drawing.Point(13, 26)
$labelStringToEncode.Margin = '4, 0, 4, 0'
$labelStringToEncode.Name = 'labelStringToEncode'
$labelStringToEncode.Size = New-Object System.Drawing.Size(117, 17)
$labelStringToEncode.TabIndex = 0
$labelStringToEncode.Text = 'String to Encode:'

$toolstripstatuslabel.Name = 'toolstripstatuslabel'
$toolstripstatuslabel.Size = New-Object System.Drawing.Size(160, 20)
$toolstripstatuslabel.Text = 'Powered by vcloud-lab.com'
$statusstrip.ResumeLayout()
$picturebox.EndInit()
$formEncodeDecodeString.ResumeLayout()

$InitialFormWindowState = $formEncodeDecodeString.WindowState
$formEncodeDecodeString.add_Load($Form_StateCorrection_Load)
$formEncodeDecodeString.add_FormClosed($Form_Cleanup_FormClosed)
$formEncodeDecodeString.ShowDialog() | Out-Null