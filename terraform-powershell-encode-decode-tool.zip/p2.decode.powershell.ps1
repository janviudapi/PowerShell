# Example decoding a UTF8 encoded string
$encodedString = "SGVsbG8sIFBvd2Vyc2hlbGwh" # Base64 for "Hello, PowerShell!" (UTF8)
$decodedBytes = [System.Convert]::FromBase64String($encodedString)
$decodedString = [System.Text.Encoding]::UTF8.GetString($decodedBytes)
Write-Host "Decoded String (UTF8): $decodedString"

# Example decoding a Unicode encoded string
$encodedStringUnicode = "SABlAGwAbABvACwAIABQAG8AdwBlAHIAcwBoAGUAbABsACEA" # Base64 for "Hello, PowerShell!" (Unicode)
$decodedBytesUnicode = [System.Convert]::FromBase64String($encodedStringUnicode)
$decodedStringUnicode = [System.Text.Encoding]::Unicode.GetString($decodedBytesUnicode)
Write-Host "Decoded String (Unicode): $decodedStringUnicode"

$encodedString = "UGFzc3dvcmQxMjMh" # Base64 for "Hello, PowerShell!" (UTF8)
$decodedBytes = [System.Convert]::FromBase64String($encodedString)
$decodedString = [System.Text.Encoding]::UTF8.GetString($decodedBytes)
Write-Host "Decoded String (UTF8): $decodedString"
