$originalString = "Hello, PowerShell!"
$bytes = [System.Text.Encoding]::UTF8.GetBytes($originalString)
$encodedString = [System.Convert]::ToBase64String($bytes)
Write-Host "Encoded String (UTF8): $encodedString"

# Example using Unicode encoding
$bytesUnicode = [System.Text.Encoding]::Unicode.GetBytes($originalString)
$encodedStringUnicode = [System.Convert]::ToBase64String($bytesUnicode)
Write-Host "Encoded String (Unicode): $encodedStringUnicode"

$originalString = "Password123!"
$bytes = [System.Text.Encoding]::UTF8.GetBytes($originalString)
$encodedString = [System.Convert]::ToBase64String($bytes)
Write-Host "Encoded String (UTF8): $encodedString"