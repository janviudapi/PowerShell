# Load the necessary assemblies
#[System.Reflection.Assembly]::LoadFrom("$($workingPath)\WebDriver.dll")
Add-Type -Path "$PSScriptRoot\WebDriver.dll"
Add-Type -Path "$PSScriptRoot\WebDriver.Support.dll"

# Ensure that the ChromeDriver is accessible via PATH or specify the path
$chromeDriverPath = "$PSScriptRoot\chromedriver.exe"

# Create ChromeDriver service
$chromeService = [OpenQA.Selenium.Chrome.ChromeDriverService]::CreateDefaultService($chromeDriverPath)
$chromeService.HideCommandPromptWindow = $true
$chromeService.SuppressInitialDiagnosticInformation = $true

# Create Chrome options
$chromeOptions = New-Object OpenQA.Selenium.Chrome.ChromeOptions
$chromeOptions.AcceptInsecureCertificates = $true

# Initialize ChromeDriver
$chromeDriver = New-Object OpenQA.Selenium.Chrome.ChromeDriver($chromeService, $chromeOptions)

#Maximized window
$chromeDriver.Manage().Window.Maximize()

# Navigate to a website
$chromeDriver.Navigate().GoToUrl("https://www.google.com")

# Enter the username in the Username box
$searchBox = $chromeDriver.FindElement([OpenQA.Selenium.By]::Name("q"))

Start-Sleep -Seconds 2

#Type on the screen and press submit button
$searchBox.SendKeys('vcloud-lab.com')
$searchBox.Submit()

[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[System.Windows.Forms.SendKeys]::SendWait("^{-}")
Start-Sleep -Seconds 1
[System.Windows.Forms.SendKeys]::SendWait("^{-}")
Start-Sleep -Seconds 1
[System.Windows.Forms.SendKeys]::SendWait("^{-}")
Start-Sleep -Seconds 1

# Take the screenshot
$screenshot = $chromeDriver.GetScreenshot()

# Save the screenshot
$screenshot.SaveAsFile("C:\Temp\screenshot.png")

Start-Sleep -Seconds 10
# Cleanup
#$chromeDriver.Quit()