# Install-Package Selenium.WebDriver
# Install-Package Selenium.WebDriver.ChromeDriver

# Load the necessary assemblies
#[System.Reflection.Assembly]::LoadFrom("$($workingPath)\WebDriver.dll")
Add-Type -Path "$PSScriptRoot\WebDriver.dll"
Add-Type -Path "$PSScriptRoot\WebDriver.Support.dll"

# Ensure that the ChromeDriver is accessible via PATH or specify the path
$chromeDriverPath = "$PSScriptRoot\chromedriver.exe" # e.g., C:\path\to\chromedriver.exe

# Create ChromeDriver service
$chromeService = [OpenQA.Selenium.Chrome.ChromeDriverService]::CreateDefaultService($chromeDriverPath)
$chromeService.HideCommandPromptWindow = $true
$chromeService.SuppressInitialDiagnosticInformation = $true

# Create Chrome options
$chromeOptions = New-Object OpenQA.Selenium.Chrome.ChromeOptions
$chromeOptions.AcceptInsecureCertificates = $true

# Initialize ChromeDriver
$chromeDriver = New-Object OpenQA.Selenium.Chrome.ChromeDriver($chromeService, $chromeOptions)

#Maximized window
$chromeDriver.Manage().Window.Maximize()
#Zoom
#$chromeDriver.ExecuteScript("document.body.style.zoom = '0.8'") #$chromeDriver.ExecuteScript("document.body.style.zoom = '80%'")

# Create Actions object to Zoom
# $actions = [OpenQA.Selenium.Interactions.Actions]::new($chromeDriver)
# $actions.KeyDown([OpenQA.Selenium.Keys]::Control).SendKeys([OpenQA.Selenium.Keys]::Subtract).KeyUp([OpenQA.Selenium.Keys]::Control).Perform()
# $actions.KeyDown([OpenQA.Selenium.Keys]::Control).SendKeys('-').KeyUp([OpenQA.Selenium.Keys]::Control).Perform()
# $actions.SendKeys([OpenQA.Selenium.Keys]::Control + '-').perform()  
# browser.actions().keyDown(protractor.Key.CONTROL).sendKeys(protractor.Key.SUBTRACT).keyUp(protractor.Key.CONTROL).perform();

# Navigate to a website
$chromeDriver.Navigate().GoToUrl("https://www.google.com")

#copy XPATH
# Enter the username in the Username box
$searchBox = $chromeDriver.FindElement([OpenQA.Selenium.By]::Name("q"))

Start-Sleep -Seconds 2

#Type on the screen and press submit button
#FindElementByXPath('//*[@id="APjFqb"]').SendKeys('vcloud-lab.com')
$searchBox.SendKeys('vcloud-lab.com')
$searchBox.Submit()

[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[System.Windows.Forms.SendKeys]::SendWait("^{-}")
Start-Sleep -Seconds 1
[System.Windows.Forms.SendKeys]::SendWait("^{-}")
Start-Sleep -Seconds 1
[System.Windows.Forms.SendKeys]::SendWait("^{-}")
Start-Sleep -Seconds 1

#$wshell = New-Object -ComObject WScript.Shell
#$wshell.SendKeys("^{-}")

# $button = $chromeDriver.FindElement([OpenQA.Selenium.By]::Name("btnK"))
# $button.Submit()

#$chromeDriver.FindElementByXPath('/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]').Click()

# Take the screenshot
$screenshot = $chromeDriver.GetScreenshot()

# Save the screenshot
$screenshot.SaveAsFile("C:\Temp\screenshot.png")

Start-Sleep -Seconds 10
# Cleanup
$chromeDriver.Quit()