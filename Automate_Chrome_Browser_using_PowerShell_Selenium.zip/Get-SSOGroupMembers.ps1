
$scriptFolder = 'D:\Projects\PowerShell\VMWare.PowerCLI\Selenium_Automation'

Unblock-File "$scriptFolder\WebDriver.dll"
Unblock-File "$scriptFolder\WebDriver.Support.dll"
Unblock-File "$scriptFolder\chromedriver.exe"


$server = 'marvel.vcloud-lab.com'
$username = 'administrator@vsphere.local'
$password = 'Computer@1'

$env:PATH += ";$scriptFolder" # Adds the path for ChromeDriver.exe to the environmental variable 
 Add-Type -Path "$scriptFolder\WebDriver.dll" # Adding Selenium's .NET assembly (dll) to access it's classes in this PowerShell session
Add-Type -Path "$scriptFolder\WebDriver.Support.dll"
$ChromeDriver = New-Object OpenQA.Selenium.Chrome.ChromeDriver # Creates an instance of this class to control Selenium and stores it in an easy to handle variable
$url = "https://$server/ui"
$chromeDriver.Navigate().GoToURL($url) # Browse to the specified website
#$ChromeDriver.FindElementByName("q").SendKeys("mavericksevmont tech blog") # Methods to find the input textbox for google search and then to type something in it
Start-Sleep -Seconds 2
$ChromeDriver.FindElementById("details-button").Click() # Method to submit request to the button
Start-Sleep -Seconds 2
$chromeDriver.FindElementById('proceed-link').Click()
Start-Sleep -Seconds 2
$ChromeDriver.FindElementById("details-button").Click() # Method to submit request to the button
Start-Sleep -Seconds 2
$chromeDriver.FindElementById('proceed-link').Click()
Start-Sleep -Seconds 2
#$chromeDriver.SwitchTo().ActiveElement().dismiss() #.alert('cancel') # | Get-Member

$chromeDriver.FindElementById('username').Clear()
$chromeDriver.FindElementById('username').SendKeys($username)
Start-Sleep -Seconds 2
$chromeDriver.FindElementById('password').Clear()
$chromeDriver.FindElementById('password').SendKeys($password)
Start-Sleep -Seconds 2
$chromeDriver.FindElementById('submit').Click()
Start-Sleep -Seconds 2

$grpUrl = "https://$server/ui/app/admin/sso-users/groups"
$chromeDriver.Navigate().GoToURL($grpUrl )

Start-Sleep -Seconds 2

$groups = 'ActAsUsers', 'Administrators'

foreach ($group in $groups) {
    $newurl = "https://$server/ui/psc-ui/ctrl/psc/tenant/groupmembers/all?groupname=$group%40vsphere.local"
    $chromeDriver.Navigate().GoToURL($newurl)
    $users = ($chromeDriver.PageSource -replace '<html><head></head><body><pre style="word-wrap: break-word; white-space: pre-wrap;">') -replace '</pre></body></html>' | ConvertFrom-Json

    $users.Users | Select-Object @{L='group';E={$group}}, name, domain
}

#$chromeDriver.Quit()


#$chromeDriver.FindElementById('username').SendKeys($username)
#$chromeDriver.FindElementById('password').SendKeys($password)
#$chromeDriver.FindElementById('submit').Click()

#$ieDriver = New-Object OpenQA.Selenium.IE.InternetExplorerOptions
#$ieDriver.InitialBrowserUrl = $url

#$chromeDriver | Get-Member

#$ChromeDriver.Quit()

#$chromeDriver.Close()
#$chromeDriver.Dispose()
