[System.Convert]::ToBoolean('true').GetType()
[System.Convert]::ToBoolean('false').GetType()
[System.Convert]::ToBoolean('true')
[System.Convert]::ToBoolean('false')

[System.Convert]::ToBoolean(0)
[System.Convert]::ToBoolean(1)
[System.Convert]::ToBoolean(100)
[System.Convert]::ToBoolean(001)

[System.Convert]::ToBoolean('Yes')

#####################################################

$rawData = Import-Csv -Path "$PSScriptRoot\info.csv"
$rawData | Get-Member -Name Pass

# Name MemberType   Definition
# ---- ----------   ----------
# Pass NoteProperty string Pass=true

$data = Import-Csv -Path "$PSScriptRoot\info.csv" | ForEach-Object {
    $_.Pass = [System.Convert]::ToBoolean($_.Pass)
    $_
}
$data | Get-Member -Name Pass

# Name MemberType   Definition
# ---- ----------   ----------
# Pass NoteProperty bool Pass=True

#####################################################

[bool]::Parse('true').GetType()
[bool]::Parse('false')

[bool]::Parse(0)
[bool]::Parse('Yes')

[bool]0
[bool]1

#####################################################

$rawData = Import-Csv -Path "$PSScriptRoot\info.csv"
$data = $rawData | Select-Object *, @{Name='Pass_Bool'; Expression={[bool]::Parse($_.Pass)}}

# Student Pass  Pass_Bool
# ------- ----  ---------
# Roman   true       True
# Timothy false     False

$data | Get-Member -Name Pass, Pass_Bool


# Name      MemberType   Definition
# ----      ----------   ----------
# Pass      NoteProperty string Pass=true
# Pass_Bool NoteProperty System.Boolean Pass_Bool=True

$rawData = Import-Csv -Path "$PSScriptRoot\info.csv"
$data = $rawData | ForEach-Object {
    #Clean the dollar sign if present, then convert
    $replaceDoller = $_.IsActive.replace('$','')
    $_.IsActive = [System.Convert]::ToBoolean($replaceDoller)
    $_
}

# Student Pass  IsActive
# ------- ----  --------
# Roman   true      True
# Timothy false     False

$data | Get-Member -Name Pass, IsActive

# Name     MemberType   Definition
# ----     ----------   ----------
# Pass     NoteProperty string Pass=true
# IsActive NoteProperty bool IsActive=True



$rawData | Get-Member -Name Pass, IsActive

# Name     MemberType   Definition
# ----     ----------   ----------
# Pass     NoteProperty string Pass=true
# IsActive NoteProperty bool IsActive=True
