#Import-Module Nutanix.Cli -Prefix Ntnx
#Import-Module Nutanix.Prism.Common -Prefix Ntnx
#Import-Module Nutanix.Prism.PS.Cmds -Prefix Ntnx

$prism = '192.168.34.101'
$userName = 'admin'
$password = 'Computer@123'
$csvFile = 'Clone_Linux_VMs.csv'

$sourceVMUsername = 'linuxadmin'
$sourceVMPassword = 'Computer@123'

$secureString = ConvertTo-SecureString -String $password -Force -AsPlainText
#$credntial = [System.Management.Automation.PSCredential]::new($username,$secureString)

$ntnxConnection = Connect-NTNXCluster -Server $prism -UserName $userName -Password $secureString -AcceptInvalidSSLCerts -ForcedConnection
#Connect-NutanixV3PrismServer #Disconnect-NutanixV3PrismServer Connect-NtnxPrismCentral 
Write-Host "$((Get-Date).DateTime) | Server: $($ntnxConnection.Server) | IsConnected: $($ntnxConnection.IsConnected) | UserName: $($ntnxConnection.UserName)"

$currentPath = $PSScriptRoot
$csvInfo = Import-Csv -Path $currentPath\$csvFile

foreach ($row in $csvInfo)
{
    $sourceVMName = $row.SourceVMName
    $sourceVM = Get-NTNXVM | Where-Object {$_.vmName -eq $sourceVMName }
    $newVMName = $row.NewVMName
    Write-Host "$((Get-Date).DateTime) | SourceVM: $sourceVMName | isFound: Yes"

    $cloneSpec = New-NTNXObject -Name VMCloneSpecDTO 
    $cloneSpec.name = $newVMName

    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isCloning: Yes"
    Clone-NTNXVirtualMachine -vmId $sourceVM.VmId -SpecList $cloneSpec | Out-Null

    $cloneTask = Get-NTNXTask | Where-Object {($_.operationType -match 'VmClone|SnapshotCreate') -or ($_.progressStatus -eq 'VmClone')}
    While ($cloneTask)
    {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | OperationType: $($cloneTask.operationType[0]) | ProgressStatus: $($cloneTask.progressStatus[0])"
        $cloneTask = Get-NTNXTask | Where-Object {($_.operationType -match 'VmClone|SnapshotCreate') -or ($_.progressStatus -eq 'VmClone')}
        #$cloneTask | Select-Object operationType, progressStatus
        Start-Sleep -Seconds 10
    }
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isCloned: Yes"
    
    #Write-Host "PowerOn VM: $newVMName"
    $createdVM = Get-NTNXVM | Where-Object {$_.vmName -eq $newVMName }
    $powerOnTask = Set-NTNXVMPowerOn -VmId $createdVM.vmId
    While (Test-Connection -ComputerName $row.SourceVMIP -Count 1 -Quiet )
    {
        #$powerOnTask
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isPoweredOn: Running"
        Start-Sleep -Seconds 15
    }
    Start-Sleep -Seconds 10
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isPoweredOn: Completed"
    #Get-NTNXTask
    if (Test-Path $currentPath\suppliments\set-newip.sh)
    {
        Remove-Item $currentPath\suppliments\set-newip.sh -Force
    }

$newIpConfig = @"
#!/bin/bash
sudo nmcli con mod "$($row.SourceVMEthName)" ipv4.method manual
sudo nmcli con mod "$($row.SourceVMEthName)" ipv4.addresses $($row.NewVMIP)/$($row.NewVMSubnet)
sudo nmcli con mod "$($row.SourceVMEthName)" ipv4.gateway $($row.NewVMGateway)
sudo nmcli con mod "$($row.SourceVMEthName)" ipv4.dns "192.168.34.11,192.168.34.12"
sudo nmcli con down "$($row.SourceVMEthName)"
sudo nmcli con up "$($row.SourceVMEthName)"
exit
"@

    $newIpConfig | Out-File -FilePath "$currentPath\suppliments\set-newip.sh" -Force #-Encoding utf8
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isCopyShScriptIP: Running"
    sshpass -p "$sourceVMPassword" scp -o StrictHostKeyChecking=no "$currentPath\suppliments\set-newip.sh" "unixsupport@$($row.SourceVMIP):/tmp"
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isCopyShScriptIP: Completed | isShScriptSetx: Running"
    #dos2unix required utf8
    sshpass -p "$sourceVMPassword" ssh -o StrictHostKeyChecking=no unixsupport@$($row.SourceVMIP) 'dos2unix /tmp/set-newip.sh; chmod +x /tmp/set-newip.sh'
    Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isShScriptSetx: Completed | isNewIpSet: Running"
    #sshpass -p "$sourceVMPassword" ssh -o StrictHostKeyChecking=no unixsupport@$($row.SourceVMIP) 'chmod +x /tmp/set-newip.sh'
    sshpass -p "$sourceVMPassword" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -o ServerAliveInterval=5 unixsupport@172.17.218.139 "sudo /tmp/set-newip.sh"
    Start-Sleep -Seconds 2
    if (Test-Connection -ComputerName $($row.NewVMIP) -Count 2 -Quiet)
    {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isNewIpSet: Completed" -BackgroundColor DarkGreen
    }
    else {
        Write-Host "$((Get-Date).DateTime) | NewVM: $newVMName | isNewIpSet: Failed" -BackgroundColor DarkRed
    }
        
}